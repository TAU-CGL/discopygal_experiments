from PyQt5 import QtCore, QtGui

PREDEFINED_COLORS = {
    "white": QtCore.Qt.white,
    "black": QtCore.Qt.black,
    "cyan": QtCore.Qt.cyan,
    "darkCyan": QtCore.Qt.darkCyan,
    "red": QtCore.Qt.red,
    "darkRed": QtCore.Qt.darkRed,
    "magenta": QtCore.Qt.magenta,
    "darkMagenta": QtCore.Qt.darkMagenta,
    "green": QtCore.Qt.green,
    "darkGreen": QtCore.Qt.darkGreen,
    "yellow": QtCore.Qt.yellow,
    "darkYellow": QtCore.Qt.darkYellow,
    "blue": QtCore.Qt.blue,
    "darkBlue": QtCore.Qt.darkBlue,
    "gray": QtCore.Qt.gray,
    "darkGray": QtCore.Qt.darkGray,
    "lightGray": QtCore.Qt.lightGray,
    "orange": "#ed900e",
}

def str_to_color(color: str):
    """
    Convert DiscoPygal color string to a QColor

    The following syntax is supported:
        * One of the following strings: 
            white, black, cyan, darkCyan,
            red, darkRed, magenta, darkMagenta,
            green, darkGreen, yellow, darkYellow,
            blue, darkBlue, gray, darkGray, lightGray
        * Hex value in the format "#RRGGBB" (i.e. "#FF3EAA")
        * Comma seperated RGB in the format "RGB r,g,b" (i.e. "RGB 21,46,123")
        * Comma seperated HSV in the format "HSV h,s,v" (i.e. "HSV 278,127,43")
    
    If the string doesn't match any of the above, black color is returned.

    :param s: color string
    :type s: str

    :return: valid QColor
    :rytpe: :class:`QtGui.QColor`
    """
    color = color.strip()
    
    color = PREDEFINED_COLORS.get(color, color)
    if isinstance(color, QtCore.Qt.GlobalColor):
        return color
    
    if color.startswith('#'):
        try:
            color = color.replace('#', '').strip()
            if len(color) != 6:
                raise Exception()
            r = int(color[0:2], 16)
            g = int(color[2:4], 16)
            b = int(color[4:6], 16)
            return QtGui.QColor.fromRgb(r, g, b)
        except:
            return QtCore.Qt.black
    
    if color.startswith('RGB'):
        try:
            color = color.replace('RGB', '').strip()
            r, g, b = color.split(',')
            r = int(r)
            g = int(g)
            b = int(b)
            return QtGui.QColor.fromRgb(r, g, b)
        except:
            return QtCore.Qt.black
    
    if color.startswith('HSV'):
        try:
            color = color.replace('HSV', '').strip()
            h, color, v = color.split(',')
            h = int(h)
            color = int(color)
            v = int(v)
            return QtGui.QColor.fromHsv(h, color, v)
        except:
            return QtCore.Qt.black

    return QtCore.Qt.black


def make_transparent(color, alpha=63):
    """
    Get a QColor and make it transparent with a given alpha

    :param color: color to modify
    :type color: :class:`QtGui.QColor`
    :param alpha: alpha transparency value
    :type alpha: :class:`int`

    :return: new transparent color
    :rtype: :class:`QtGui.QColor`
    """
    color = QtGui.QColor(color)
    color.setAlpha(alpha)
    return color