import os
import sys
import shutil
import importlib
import pandas as pd
from discopygal.experiments.scenarios_runner import run_scenarios, get_latest_dir, get_results_experiment_path, \
    get_scenario_as_inputs

USAGE_MESSAGE = """
Usage:
For running full new experiment:    <result_root_dir> <scenarios_file>
For resuming last full experiment:  <result_root_dir> <scenarios_file> resume
For running single chunk:           <result_root_dir> <scenarios_file> <number_of_chunks> <chunk_number>
For merging all chunk results:      <result_root_dir> <scenarios_file> <number_of_chunks> end
"""


# Args: result_root_dir, scenarios_file,                                # To run all scenarios in new experiment (full experiment)
# Args: result_root_dir, scenarios_file, resume                         # To resume last experiment (full experiment)
# Args: result_root_dir, scenarios_file,                                # To resume from latest
# Args: result_root_dir, scenarios_file, number_of_chunks, chunk_number # To run chunk
# Args: result_root_dir, scenarios_file, number_of_chunks, end          # To create final dir


def get_chunk_slice(chunk_index, number_of_chunks, number_of_elements):
    # Big chunks are larger by 1 than small chunks
    # Big chunks are before small chunks.
    size_of_small_chunk = number_of_elements // number_of_chunks
    size_of_big_chunk = size_of_small_chunk + 1
    number_of_big_chunks = number_of_elements % number_of_chunks
    if chunk_index < number_of_big_chunks:
        # the chunk is big
        start_index = chunk_index * size_of_big_chunk
        size_of_chunk = size_of_big_chunk
    else:
        # the chunk is small
        start_index = number_of_big_chunks * size_of_big_chunk + (chunk_index - number_of_big_chunks) * size_of_small_chunk
        size_of_chunk = size_of_small_chunk

    return slice(start_index, start_index + size_of_chunk)


def load_scenarios_and_handlers(scenarios_file):
    sys.path.append(os.path.dirname(scenarios_file))
    scenarios_module_name = os.path.basename(scenarios_file).rstrip(".py")
    scenarios_module = importlib.import_module(scenarios_module_name)
    scenarios = getattr(scenarios_module, "SCENARIOS")
    extra_result_handlers = getattr(scenarios_module, "RESULT_HANDLERS", None)
    return scenarios, extra_result_handlers


def main():
    args = sys.argv[1:]
    if not 2 <= len(args) <= 4:
        print(USAGE_MESSAGE)
        sys.exit(1)

    results_root_dir = args[0]
    scenarios_file = args[1]
    scenarios, extra_result_handlers = load_scenarios_and_handlers(scenarios_file)


    # Run full experiment
    if len(args) < 4:
        resume_latest = (len(args) == 3 and args[2] == "resume")
        print(f"Running full experiment from {scenarios_file} ({resume_latest=})")
        run_scenarios(scenarios, results_root_dir, extra_result_handlers, resume_latest)
    else:
        number_of_chunks = int(args[2])
        assert 0 < number_of_chunks

        # Run single chunk
        if args[3] != "end":
            chunk_index = int(args[3])
            assert chunk_index < number_of_chunks
            chunk_slice = get_chunk_slice(chunk_index, number_of_chunks, len(scenarios))
            print(f"Running {chunk_index=}, scenarios: {chunk_slice.start} to {chunk_slice.stop - 1} from file: {scenarios_file}")
            run_scenarios(scenarios[chunk_slice], f"{results_root_dir}/chunk_{chunk_index}", extra_result_handlers)
            return

        # Merge all results at end
        print(f"Merging all results from {results_root_dir}")
        all_results_path = get_results_experiment_path(f"{results_root_dir}/all")
        print(f"Saving at {all_results_path}")
        chunk_dirs = os.listdir(results_root_dir)
        os.makedirs(all_results_path)

        results_per_chunk = []
        for chunk_name in chunk_dirs:
            assert chunk_name.startswith("chunk_")
            chunk_index = int(chunk_name.split('_')[1])
            chunk_dir = get_latest_dir(f"{results_root_dir}/{chunk_name}")
            print(f"Copying from {chunk_dir}")
            os.system(f"echo {chunk_dir} >> {all_results_path}/chunks_dirs.txt")

            chunk_index_offset = get_chunk_slice(chunk_index, number_of_chunks, len(scenarios)).start
            chunk_results = pd.read_csv(f"{chunk_dir}/results.csv")
            chunk_results["scenario_index"] += chunk_index_offset
            results_per_chunk.append(chunk_results)
            for scenario_file in os.listdir(chunk_dir):
                if scenario_file.startswith("scenario_"):
                    scenario_index = int(scenario_file.split('.')[0].split('_')[1])
                    shutil.copy(f"{chunk_dir}/{scenario_file}", f"{all_results_path}/scenario_{chunk_index_offset + scenario_index}.csv")

        all_results = pd.concat(results_per_chunk)

        # Add missing scenarios
        for scenario_index, scenario in enumerate(scenarios):
            if scenario_index not in list(all_results["scenario_index"]):
                scenario_inputs = get_scenario_as_inputs(scenario)
                all_results.loc[len(all_results)] = [scenario_index] + scenario_inputs + [float("NaN")] * (len(all_results.columns) - len(scenario_inputs) - 1)

        all_results = all_results.sort_values(by=["scenario_index"])
        all_results.to_csv(f"{all_results_path}/results.csv", index=False)


if __name__ == "__main__":
    main()
