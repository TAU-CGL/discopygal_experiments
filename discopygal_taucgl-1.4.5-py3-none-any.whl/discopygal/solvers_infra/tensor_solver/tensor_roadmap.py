import networkx as nx
import itertools

from ...geometry_utils import collision_detection, conversions
from ...bindings import Point_2, Segment_2, Point_d, FT
from ...solvers_infra.roadmap import Roadmap
from ...solvers_infra.SamplingSolver import shortest_path_length
from ...solvers_infra.operations_counter import OperationsCounter


class TensorRoadmap(object):
    """
    A class that represents a tensor roadmap, which couples a roadmap of each robot
    (which was built separately) into one large graph product representing motion of
    all the robots.
    Note that since for most (nontrivial) cases the explicit roadmap is intractable,
    we generate an interface which allows us to query the tensor roadmap without
    explicitly building it - and also remembering the subgraph of queries we made.

    Graphs are represented using networkx.
    *Vertices of a roadmap of a single robot are Point_2, while vertices of the
    tensor roadmap are of type Point_d.*

    :param roadmaps: a mapping between each robot and its roadmap
    :type roadmaps: dict<:class:`~discopygal.solvers_infra.Robot`, :class:`~discopygal.solvers_infra.roadmap.Roadmap`>
    :param scene: scene to solve
    :type scene: :class:`~discopygal.solvers_infra.Scene`
    :param nearest_neighbors_class: a nearest neighbors algorithm class.
    :type nearest_neighbors_class: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors`
    :param metric: a metric for choosing best edge, can be different then the nearest_neighbors metric!
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param metric: a sampler to use for sampling points
    :type metric: :class:`~discopygal.solvers_infra.sampler.Sampler`
    """
    def __init__(self, roadmaps, scene, nearest_neighbors_class, metric, sampler):
        self.roadmaps = roadmaps
        self.scene = scene
        self.metric = metric

        self.robots = list(self.roadmaps.keys()) # remember a *consistent* ordering on the robots
        self.T = Roadmap(scene, self.metric, nearest_neighbors_class, sampler)  # the subgraph of the tensor roadmap of discovered vertices and edges
        self.start = conversions.Point_2_list_to_Point_d([robot.start for robot in self.robots])
        self.end = conversions.Point_2_list_to_Point_d([robot.end for robot in self.robots])
        self.heuristic_measures = {robot: {} for robot in self.robots}

    def nearest_tensor_vertex(self, tensor_point):
        """
        Get a tensor point and return a tensor vertex (i.e. vertex of hat(V), the vertices of the tensor graph)
        that is the closest when comparing in the high dimensional space.

        :param tensor_point: a point in the high dimensional space
        :type tensor_point: :class:`~discopygal.bindings.Point_d`
        """
        if not self.T.graph.has_node(tensor_point):
            return self.T.nearest_neighbors.k_nearest(tensor_point, 1)[0]
        else:
            # If we query an existing node, we will get it (since dist=0)
            # Hence we want the *second* closest node
            knn = self.T.nearest_neighbors.k_nearest(tensor_point, 2)
            if len(knn) == 1:
                # If it is the only vertex return it
                return knn[0]
            for point in knn:
                if point != tensor_point:
                    return point

    def clean_tensor_edge(self, p, q):
        """
        Get a tensor edge (made of tensor vertices p and q) and clean it, i.e.
        make sure that no two robots are intersecting each other.
        If two robots intersect - then make sure one of them stays in place.

        :param p: first vertex
        :type p: :class:`~discopygal.bindings.Point_d`
        :param q: second vertex
        :type q: :class:`~discopygal.bindings.Point_d`

        :return: q', a vertex for which (p,q') is a valid motion
        :rtype: :class:`~discopygal.bindings.Point_d`
        """
        if p == q:
            return None
        for i in range(len(self.robots)):
            for j in range(i+1, len(self.robots)):
                robot1 = self.robots[i]
                robot2 = self.robots[j]
                edge1 = Segment_2(
                    Point_2(p[2*i], p[2*i+1]),
                    Point_2(q[2*i], q[2*i+1])
                )
                edge2 = Segment_2(
                    Point_2(p[2*j], p[2*j+1]),
                    Point_2(q[2*j], q[2*j+1])
                )
                if collision_detection.collide_two_robots(robot1, edge1, robot2, edge2):
                    # If they collide, put robot2 in place and try again
                    coords = []
                    for k in range(q.dimension()):
                        if k // 2 == j:
                            coords.append(p[k])
                        else:
                            coords.append(q[k])
                    q_prime = Point_d(q.dimension(), coords)
                    if q == q_prime:
                        return None
                    return self.clean_tensor_edge(p, q_prime)
        return q

    def get_neighbors_in_tensor_product(self, point: Point_d):
        neighbors = []
        points = conversions.Point_d_to_Point_k_list(point, 2)
        for p in itertools.product(
            *[roadmap.graph.neighbors(point) for roadmap, point in zip(self.roadmaps.values(), points)]):
            neighbors.append(conversions.Point_k_list_to_Point_d(p))

        return set(neighbors)

    def find_best_edge(self, tensor_vertex, tensor_point):
        """
        Given a vertex in the tensor graph and a random tensor point,
        choose an edge in the tensor graph that is made of the edges in the original
        roadmaps that take us the closest to the tensor point.

        Also note that if two robots collide, we try to make one of them to stay in place
        (i.e. some robots might stay in place, but at least one robot is guaranteed to move - if an edge was added).

        :return: True if an edge was added
        :rtype: :class:`bool`
        """
        vertex = []
        tensor_vertex = conversions.Point_d_to_Point_k_list(tensor_vertex, 2)
        tensor_point = conversions.Point_d_to_Point_k_list(tensor_point, 2)
        for i, robot in enumerate(self.robots):
            best_p = None
            best_dist = None
            for edge in self.roadmaps[robot].edges(tensor_vertex[i]):
                if edge[0] == tensor_vertex[i]:
                    p = edge[1]
                else:
                    p = edge[0]
                dist = self.metric.dist(p, tensor_point[i])
                if best_dist is None or dist < best_dist:
                    best_p = p
                    best_dist = dist
            vertex.append(best_p)

        vertex = conversions.Point_k_list_to_Point_d(vertex)
        tensor_vertex = conversions.Point_k_list_to_Point_d(tensor_vertex)

        # Make sure robots are not colliding
        vertex = self.clean_tensor_edge(tensor_vertex, vertex)
        if vertex is None:
            # If we couldn't connect, then ignore
            return False

        self.T.add_edge(tensor_vertex, vertex)
        return vertex

    def try_connecting(self, vertex1, vertex2):
        """
        Try connecting two vertices of the tensor graph.
        We do that by the method proposed by de Berg:
        http://www.roboticsproceedings.org/rss05/p18.html
        (Finding each path individually and then trying to find a prioritization
        which is collision free).
        Return True if we succeeded connecting.

        :param vertex1: first vertex in the tensor roadmap
        :type vertex1: :class:`~discopygal.bindings.Point_d`
        :param vertex2: second vertex in the tensor roadmap
        :type vertex1: :class:`~discopygal.bindings.Point_d`

        :return: True if we connected the vertices
        :rtype: :class:`bool`
        """
        # Find path for eact robot
        vertex1_points = conversions.Point_d_to_Point_k_list(vertex1, 2)
        vertex2_points = conversions.Point_d_to_Point_k_list(vertex2, 2)
        paths = []
        for i, robot in enumerate(self.robots):
            if not nx.algorithms.has_path(self.roadmaps[robot].graph, vertex1_points[i], vertex2_points[i]):
                return False
            path = nx.algorithms.shortest_path(
                self.roadmaps[robot].graph, vertex1_points[i], vertex2_points[i])
            paths.append(path)

        # Generate the priority graph
        priority_graph = nx.DiGraph()
        priority_graph.add_nodes_from(range(len(self.robots)))
        for i, robot_i in enumerate(self.robots):
            for j, robot_j in enumerate(self.robots):
                if i == j:
                    continue
                # Robot i stays in place in its target
                edge_i = conversions.create_segment_2(vertex2_points[i], vertex2_points[i])

                # Robot j moves along its path
                for k in range(len(paths[j])-1):
                    edge_j = conversions.create_segment_2(paths[j][k], paths[j][k+1])
                    if collision_detection.collide_two_robots(robot_i, edge_i, robot_j, edge_j):
                        # If j collides with i when i is in its target, j needs to reach the target before i
                        priority_graph.add_edge(j, i)

                # Robot i stays in place in its start
                edge_i = conversions.create_segment_2(vertex1_points[i], vertex1_points[i])

                # Robot j moves along its path again
                for k in range(len(paths[j])-1):
                    edge_j = conversions.create_segment_2(paths[j][k], paths[j][k+1])
                    if collision_detection.collide_two_robots(robot_i, edge_i, robot_j, edge_j):
                        # If j collides with i when i is in its start, i needs to reach the target before j
                        priority_graph.add_edge(i, j)

        # If there are cycles, no ordering can be found
        if not nx.algorithms.is_directed_acyclic_graph(priority_graph):
            return False

        # Build a path based on the topological ordering
        ptr = [p for p in vertex1_points] # start at vertex1
        vertex_path = [ptr]
        for r in nx.algorithms.topological_sort(priority_graph):
            for v in paths[r]:
                # Advance only the currect robot
                new_ptr = [p for p in ptr]
                new_ptr[r] = v

                ptr_vertex = conversions.Point_k_list_to_Point_d(ptr)
                new_ptr_vertex = conversions.Point_k_list_to_Point_d(new_ptr)
                if new_ptr_vertex == self.end:
                    if not self.T.graph.has_node(ptr_vertex):
                        self.T.add_point(ptr_vertex, cost=float("inf"))
                    if not self.T.graph.has_node(new_ptr_vertex):
                        self.T.add_point(new_ptr_vertex, cost=float("inf"))
                    self.T.add_edge(ptr_vertex, new_ptr_vertex)
                elif not self.T.graph.has_node(new_ptr_vertex) or \
                        self.cost(new_ptr_vertex) > self.cost(ptr_vertex) + self.cost(ptr_vertex, new_ptr_vertex):
                    self.connect_to_roadmap(new_ptr_vertex, ptr_vertex)

                ptr = new_ptr
                vertex_path.append(ptr)

        assert ptr == vertex2_points  # We should have reached the destination
        return vertex_path

    def get_tensor_subgraph(self):
        """
        Get the subgraph of the tensor roadmap discovered so far
        """
        return self.T

    # def heuristic_measure_for_single_robot(self, point, robot):
    #     for p in self.heuristic_measures[robot]:
    #         if self.metric.dist(p, point) < 0.1:
    #             return self.heuristic_measures[robot][p]

    #     single_solver = PRM(100, 15, metric=self.metric)
    #     new_robot = type(robot).from_dict(robot.to_dict())
    #     new_robot.start = point
    #     new_scene = Scene(obstacles=self.scene.obstacles, robots=[new_robot])
    #     single_solver.load_scene(new_scene)
    #     paths = single_solver.solve().paths
    #     if new_robot in paths:
    #         prm_path_length = paths[new_robot].calculate_length(self.metric)
    #     else:
    #         prm_path_length = float("inf")
    #     single_solver = ExactSingle(0.01)
    #     single_solver.load_scene(new_scene)
    #     paths = single_solver.solve().paths
    #     if new_robot in paths:
    #         exact_path_length = paths[new_robot].calculate_length(self.metric)
    #     else:
    #         exact_path_length = float("inf")
    #     self.heuristic_measures[robot][point] = min([prm_path_length, exact_path_length])
    #     return self.heuristic_measures[robot][point]

    def heuristic_measure_for_single_robot(self, point, robot):
        for p in self.heuristic_measures[robot]:
            if self.metric.dist(p, point) < 0.01:
                return self.heuristic_measures[robot][p]

        try:
            start = conversions.Point_2_to_Point_d(point)
            end = conversions.Point_2_to_Point_d(robot.end)
            self.heuristic_measures[robot][point] = shortest_path_length(self.roadmaps[robot].graph, start, end)
        except nx.NetworkXNoPath:
            self.heuristic_measures[robot][point] = float("inf")

        return self.heuristic_measures[robot][point]

    def heuristic_measure(self, point):
        # TODO: is this a good heuristic measure?
        # Option 1
        # return self.metric.dist(point, target) * random.random()

        # Option 2
        # return abs(float(self.metric.dist(point, target)) + (random.normalvariate(1,1)))

        # Option 3
        # return self.metric.dist(point, target)

        # Option 4
        h = FT(0)
        points = conversions.Point_d_to_Point_2_list(point)
        for i, robot in enumerate(self.scene.robots):
            h += self.heuristic_measure_for_single_robot(points[i], robot)
        return h

    def cost(self, vertex, vertex2=None):
        if vertex2:
            # cost = self.metric.dist(vertex, vertex2)
            cost = FT(0)
            for p,q in zip(conversions.Point_d_to_Point_2_list(vertex), conversions.Point_d_to_Point_2_list(vertex2)):
                cost += self.metric.dist(p, q)
        else:
            # cost = self.T.nodes[vertex]['cost']
            if vertex == self.start:
                cost = 0
            elif vertex == self.end:
                try:
                    cost = shortest_path_length(self.T.graph, self.start, self.end)
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    cost = float("inf")
            elif 'prev' not in self.T.points[vertex]:
                cost = float("inf")
            else:
                cost = self.cost(vertex, self.T.points[vertex]['prev']) + self.cost(self.T.points[vertex]['prev'])

        return float(cost)

    def connect_to_roadmap(self, new_vertex, prev_vertex):
        """
        Disconnects previous connection
        """
        assert new_vertex != prev_vertex
        # if not self.check_valid_edge(new_vertex, prev_vertex):
        #     return False
        self.T.add_point(new_vertex, cost=float("inf"))
        if 'prev' in self.T.points[new_vertex]:
            if self.T.points[new_vertex]['prev'] == prev_vertex:
                return
            else:
                self.T.graph.remove_edge(new_vertex, self.T.points[new_vertex]['prev'])

        self.T.add_edge(new_vertex, prev_vertex)
        self.T.points[new_vertex]['prev'] = prev_vertex

    def rewire(self, vertex):
        for neighbor in self.T.graph.neighbors(vertex):
            if self.cost(neighbor) > self.cost(vertex) + self.cost(vertex, neighbor) and \
               self.T.is_edge_valid(vertex, neighbor):
                self.connect_to_roadmap(neighbor, vertex)
