import math
from fibonacci_heap_mod import Fibonacci_heap, Entry
from math import isclose
import numpy as np
from discopygal.bindings import Point_d
from .implicitroadmap import ImplicitRoadmap


class GraphNode:
    def __init__(
        self,
        real_coords,
        dim,
        heuristic_count,
        resolutions,
        parent=None,
        g_cost=math.inf,
        is_goal=False,
    ):
        self.real_coords = real_coords  # Point_d object
        self.dim = dim
        self.resolutions = resolutions
        self.lattice_coords = {}
        for res in resolutions:
            self.lattice_coords[res] = [0] * self.dim
        ## lattice coords for each resolution if the node is in the resolution lattice
        self.g_cost = g_cost
        self.parent = parent
        self.is_goal = is_goal
        self.current_open_queues = [False for _ in range(heuristic_count)]
        self.resolution_indices = []
        self.expanded_from_queue = {
            res: False for res in resolutions
        }  ## CLOSED from paper
        self.entries = [None for _ in range(heuristic_count)]

    def get_resolution_indices(self, resolutions_data, start, show_details=False):
        """
        Determine which resolution lattices this point belongs to by checking if its
        coordinates can be expressed as integer lattice coordinates for each resolution.

        :param resolutions_data: dict of resolution data, keys are resolution numbers, values are ResolutionData objects
        :type resolutions_data: : python dict
        :param start: Start point
        :type start: :class:`~discopygal.bindings.Point_d`

        :return: List of resolution indices that this point belongs to
        :rtype: list of float
        """
        if len(self.resolution_indices) > 0:
            # if show_details:
            #     print(f"    Point belongs to resolutions: {self.resolution_indices}")
            return self.resolution_indices

        for resolution in resolutions_data.keys():
            # Convert Point_d objects to numpy arrays for arithmetic
            self_coords_np = np.array(
                [self.real_coords[i] for i in range(self.real_coords.dimension())]
            )
            start_coords_np = np.array(
                [start.real_coords[i] for i in range(start.real_coords.dimension())]
            )

            coords = resolutions_data[resolution].res_inverse_generator_matrix @ (
                self_coords_np - start_coords_np
            )

            ## TODO: CHANGE THIS
            if all(
                isclose(coords[i], round(coords[i]), abs_tol=1e-6)
                for i in range(len(coords) - 1, -1, -1)
            ):  # Tighter tolerance
                self.lattice_coords[resolution] = [
                    round(coords[i]) for i in range(len(coords))
                ]  # Use round() instead of int()
                self.resolution_indices.append(resolution)

        # if show_details:
        #     # Simple summary for all points
        #     print(f"    Point belongs to resolutions: {self.resolution_indices}")

        return self.resolution_indices


# TODO: check if we need this class
# class GraphEdge:
#     def __init__(self, src, dest, metric):
#         self.src = src
#         self.dest = dest
#         self.segment = conversions.create_segment_2(src.point, dest.point)
#         self.cost = metric.dist(src.point, dest.point).to_double()


class Graph(ImplicitRoadmap):
    """
    Graph class for implicit search.
    Uses the MRMH-A* search algorithm.
    """

    def __init__(
        self,
        start,
        goal,
        dim,
        radius,
        w1,
        w2,
        heuristics,
        resolutions_data,
        metric,
        writer,
        scene,
    ):
        super().__init__(scene, metric)
        self.resolutions_data = resolutions_data
        self.resolutions = list(resolutions_data.keys())
        self.heuristic_count = len(heuristics.keys())
        self.dim = dim
        self.connection_radius = radius
        self.w1 = w1
        self.w2 = w2
        self.heuristics = heuristics  # {0: function0, res 3}
        self.writer = writer
        self.edges = []
        self.OPEN = [Fibonacci_heap() for _ in range(self.heuristic_count)]
        self.non_empty_queues = set()
        self.queue_index = 0
        self.INVALID = {res: set() for res in self.resolutions}

        self.start = GraphNode(
            start, dim, self.heuristic_count, self.resolutions, None, 0, False
        )
        self.goal = GraphNode(
            goal, dim, self.heuristic_count, self.resolutions, None, math.inf, True
        )

        self.point_to_node = {
            tuple(
                self.start.real_coords[i]
                for i in range(self.start.real_coords.dimension())
            ): self.start
        }

    #     self.heuristic_functions = [self.heuristics[i][0] for i in range(1, self.heuristic_count)]
    #     self.queue_selector = QueueDTSselector(self.heuristic_count-1, self.heuristic_functions, self.start, C=100)

    def heuristic_resolution(self, index):
        """
        Get the resolution of the heuristic function.
        :param index: The index of the heuristic function
        :type index: int

        :return: The resolution of the heuristic function
        :rtype: float
        """
        return self.heuristics[index][1]

    def h(self, state, index):
        """
        Get the heuristic value of a state.
        :param state: The state to get the heuristic value of
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param index: The index of the heuristic function
        :type index: int

        :return: The heuristic value of the state
        :rtype: float
        """
        return self.heuristics[index][0](state.real_coords)

    def key(self, state, index):
        """
        Get the key of a state in a given queue.
        :param state: The state to get the key of
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param index: The index of the heuristic function
        :type index: int

        :return: The key of the state
        :rtype: float
        """
        return state.g_cost + self.w1 * self.h(state, index)

    def get_cost(self, state, neighbor):
        """
        Get the cost of an edge between two states.
        :param state: The source state
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param neighbor: The neighbor state
        :type neighbor: :class:`~discopygal.solvers_infra.GraphNode`

        :return: The cost of the edge
        :rtype: float
        """
        cost = self.metric.dist(state.real_coords, neighbor.real_coords).to_double()
        return cost

    def calculate_euclidean_distance(self, point1, point2):
        """
        Calculate Euclidean distance between two Point_d objects
        :param point1: The first point
        :type point1: :class:`~discopygal.bindings.Point_d`
        :param point2: The second point
        :type point2: :class:`~discopygal.bindings.Point_d`

        :return: The Euclidean distance between the two points
        :rtype: float
        """
        distance = 0.0
        for i in range(point1.dimension()):
            diff = float(point1[i]) - float(point2[i])
            distance += diff * diff
        return distance**0.5

    def insert_or_update(self, queue, index, state, key):
        """
        Insert or update a state in a queue if it's not already in the queue.
        :param queue: The queue to insert or update the state in
        :type queue: :class:`~discopygal.solvers_infra.Fibonacci_heap`
        :param index: The index of the queue
        :type index: int
        :param state: The state to insert or update
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param key: The key of the state
        :type key: float
        """
        if queue.m_size == 0:
            self.non_empty_queues.add(
                index
            )  # add the queue to the non_empty_queues set
        if state.current_open_queues[index]:
            queue.decrease_key(state.entries[index], key)
        else:
            new_entry = queue.enqueue(state, key)  # returns an entry element
            state.entries[index] = new_entry
            state.current_open_queues[index] = True

    def should_connect_to_goal(self, state, show_details=False):
        """
        Check if the state should be connected to the goal.
        :param state: The state to check
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param show_details: Whether to show detailed information
        :type show_details: bool

        :return: True if the state should be connected to the goal, False otherwise
        :rtype: bool
        """
        # Calculate euclidean distance between Point_d objects
        goal_distance = self.calculate_euclidean_distance(
            state.real_coords, self.goal.real_coords
        )

        # Use roadmap's collision checking
        can_connect = goal_distance <= self.connection_radius and self.is_edge_valid(
            state.real_coords, self.goal.real_coords
        )

        if show_details:
            print(
                f"      SHOULD_CONNECT_TO_GOAL: distance={goal_distance:.6f}, radius={self.connection_radius:.6f}, can_connect={can_connect}",
                file=self.writer,
            )

        return can_connect

    def get_neighbors(self, state, res, show_details=False):
        """
        Get the valid neighbors of a state in a given resolution based on the optional offsets.
        :param state: The state to get the neighbors of
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param res: The resolution to get the neighbors of
        :type res: float
        :param show_details: Whether to show detailed information
        :type show_details: bool

        :return: The neighbors of the state
        :rtype: list of :class:`~discopygal.solvers_infra.GraphNode`
        """
        neighbors = []
        res_lattice_coords = state.lattice_coords[res]

        if show_details:
            print(
                f"      GET_NEIGHBORS: resolution {res}, {len(self.resolutions_data[res].neighbors)} potential neighbors",
                file=self.writer,
            )

        valid_neighbors = 0
        invalid_point = 0
        invalid_edge = 0

        for neighbor in self.resolutions_data[res].neighbors:
            neighbor_res_lattice_coords = res_lattice_coords + neighbor.lattice_offset

            # Convert Point_d to numpy for addition, then back to Point_d
            state_coords_np = np.array(
                [state.real_coords[i] for i in range(state.real_coords.dimension())]
            )
            offset_coords_np = np.array(
                [
                    neighbor.real_offset[i]
                    for i in range(neighbor.real_offset.dimension())
                ]
            )
            neighbor_coords_np = state_coords_np + offset_coords_np
            neighbor_real_coords = Point_d(
                len(neighbor_coords_np), neighbor_coords_np.tolist()
            )

            coords_key = tuple(neighbor_res_lattice_coords)

            if coords_key in self.INVALID[res]:
                continue  # the neighbor is invalid

            point_valid = self.is_point_valid(neighbor_real_coords)
            edge_valid = (
                self.is_edge_valid(state.real_coords, neighbor_real_coords)
                if point_valid
                else False
            )

            if point_valid and edge_valid:
                neighbor_coords_tuple = tuple(
                    neighbor_real_coords[i]
                    for i in range(neighbor_real_coords.dimension())
                )
                neighbor_node = self.point_to_node.get(neighbor_coords_tuple)
                if neighbor_node is None:
                    neighbor_node = GraphNode(
                        neighbor_real_coords,
                        self.dim,
                        self.heuristic_count,
                        self.resolutions,
                    )
                    self.point_to_node[neighbor_coords_tuple] = neighbor_node

                neighbor_node.lattice_coords[res] = neighbor_res_lattice_coords
                neighbors.append(neighbor_node)
                valid_neighbors += 1
            else:
                if not point_valid:
                    invalid_point += 1
                else:
                    invalid_edge += 1
                self.INVALID[res].add(coords_key)

        if self.should_connect_to_goal(state, show_details):  ## special case for goal
            neighbors.append(self.goal)

        if show_details:
            print(
                f"      GET_NEIGHBORS RESULT: {valid_neighbors} valid, {invalid_point} invalid points, {invalid_edge} invalid edges",
                file=self.writer,
            )

        return neighbors

    def expand(self, state, h_index, show_details=False):
        """
        Expand a state in the graph.
        :param state: The state to expand
        :type state: :class:`~discopygal.solvers_infra.GraphNode`
        :param h_index: The index of the heuristic function to use
        :type h_index: int
        :param show_details: Whether to show detailed information
        :type show_details: bool
        """

        res = self.heuristic_resolution(h_index)

        if show_details:
            print(f"    EXPAND: queue {h_index}, resolution {res}", file=self.writer)
            print(
                f"      Expanding state at: {[float(state.real_coords[i]) for i in range(state.real_coords.dimension())]}",
                file=self.writer,
            )

        if h_index != 0:
            for j in range(1, self.heuristic_count):
                if (
                    self.heuristic_resolution(j) == res
                ):  # if the j'th queue also works with the same resolution
                    if state.current_open_queues[j]:
                        self.OPEN[j].delete(state.entries[j])
                        state.entries[j] = None
                        state.current_open_queues[j] = False
                        if self.OPEN[j].m_size == 0:
                            self.non_empty_queues.remove(j)

        neighbors = self.get_neighbors(state, res, show_details)
        if show_details:
            print(f"    EXPAND: Found {len(neighbors)} neighbors", file=self.writer)

        neighbors_added = 0
        neighbors_updated = 0
        for neighbor in neighbors:
            edge_cost = self.get_cost(state, neighbor)
            new_g_cost = state.g_cost + edge_cost

            if neighbor.g_cost > new_g_cost:
                old_g_cost = neighbor.g_cost
                neighbor.g_cost = new_g_cost
                neighbor.parent = state

                if old_g_cost == math.inf:
                    neighbors_added += 1
                else:
                    neighbors_updated += 1

                if neighbor.is_goal:
                    print(
                        f"GOAL FOUND! g-cost: {neighbor.g_cost:.6f}", file=self.writer
                    )
                    continue  # we don't need to expand the goal

                # Use first resolution as anchor (index 0)
                anchor_resolution = list(self.resolutions)[0]
                if neighbor.expanded_from_queue[anchor_resolution] is False:
                    # neighbor hasn't been expanded from anchor
                    self.insert_or_update(
                        self.OPEN[0], 0, neighbor, self.key(neighbor, 0)
                    )
                    for i in range(1, self.heuristic_count):
                        l = self.heuristic_resolution(i)
                        resolution_indices = neighbor.get_resolution_indices(
                            self.resolutions_data, self.start, show_details
                        )

                        if (
                            l in resolution_indices
                            and neighbor.expanded_from_queue[l] is False
                            and self.key(neighbor, i) <= self.w2 * self.key(neighbor, 0)
                        ):
                            self.insert_or_update(
                                self.OPEN[i], i, neighbor, self.key(neighbor, i)
                            )

        if show_details:
            print(
                f"    EXPAND RESULT: {neighbors_added} added, {neighbors_updated} updated",
                file=self.writer,
            )

        return neighbors_added + neighbors_updated

    def get_path_to_node(self, node):
        """
        Get the path to a node.
        :param node: The node to get the path to
        :type node: :class:`~discopygal.solvers_infra.GraphNode`

        :return: Path from the start to the node
        :rtype: list of Point_d objects
        """
        curr = node
        path = []

        # Collect path in reverse order
        while curr is not None:
            path.append(curr.real_coords)
            curr = curr.parent
        path.reverse()

        return path

    def choose_queue_index(self):
        """
        Choose a queue index to expand from.

        :return: The chosen queue index
        :rtype: int
        """
        # Round robin method -- TODO: EXPLORE other methods
        curr = self.queue_index + 1

        if len(self.non_empty_queues) == 1:  # only anchor queue is open
            return 0
        else:  # there's at least one other queue open with index in {1,...,heuristic_count-1}
            while True:
                if curr == self.heuristic_count:
                    curr = 1
                if curr in self.non_empty_queues:
                    self.queue_index = curr
                    return curr
                else:
                    curr += 1

    def MRMH_A_star_search(self):
        """
        Multi-Resolution Multi-Heuristic A* Search.

        :return: Path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """

        print("--- Starting Multi-Heuristic A* Search ---", file=self.writer)
        print(
            f"Start: {[float(self.start.real_coords[i]) for i in range(self.start.real_coords.dimension())]}",
            file=self.writer,
        )
        print(
            f"Goal: {[float(self.goal.real_coords[i]) for i in range(self.goal.real_coords.dimension())]}",
            file=self.writer,
        )
        print(
            f"Heuristics: {len(self.heuristics)}, Resolutions: {self.resolutions}",
            file=self.writer,
        )

        start_entry = self.OPEN[0].enqueue(self.start, self.key(self.start, 0))
        self.start.entries[0] = start_entry
        self.non_empty_queues.add(0)
        # self.queue_selector.initialize_method(self.start)

        # for all other queues, insert the start node if it's in the resolution of the queue
        for i in range(1, self.heuristic_count):
            new_entry = self.OPEN[i].enqueue(self.start, self.key(self.start, i))
            self.start.entries[i] = new_entry
            self.non_empty_queues.add(i)
            ## start is in all resolutions. maybe for anytime version in the future
            # if self.heuristic_resolution(i) in self.start.get_resolution_indices():
            #     self.OPEN[i].enqueue(self.start, self.key(self.start, i))
            #     self.non_empty_queues.add(i)

        print(
            f"Setup complete - {len(self.non_empty_queues)} queues active",
            file=self.writer,
        )

        iterations = 0
        max_iterations = 200000

        print(f"ENTERING MAIN LOOP...", file=self.writer)

        # while one of the queues is not empty
        while len(self.non_empty_queues) != 0 and iterations < max_iterations:
            iterations += 1

            show_details = (iterations % 20000 == 0) or (
                iterations <= 3
            )  # Show first 3 and every 20000
            show_progress = (
                iterations % 5000 == 0
            ) and not show_details  # Simple progress indicator

            if show_progress:
                print(
                    f"Progress: Iteration {iterations}, Queue size: {sum(self.OPEN[i].m_size for i in self.non_empty_queues)}, Goal g-cost: {self.goal.g_cost:.6f}",
                    file=self.writer,
                )

            if show_details:
                print(f"=== ITERATION {iterations} ===", file=self.writer)
                print(
                    f"Non-empty queues: {list(self.non_empty_queues)}", file=self.writer
                )
                for i in self.non_empty_queues:
                    print(f"  Queue {i} size: {self.OPEN[i].m_size}", file=self.writer)
                print(f"Goal g-cost: {self.goal.g_cost:.6f}", file=self.writer)

            index = self.choose_queue_index()

            if show_details:
                print(f"Chosen queue index: {index}", file=self.writer)

            curr_queue_min_key = self.OPEN[index].min().get_priority()
            anchor_min_key = self.OPEN[0].min().get_priority()

            # switch to anchor search
            if curr_queue_min_key > self.w2 * anchor_min_key:
                index = 0

            if self.goal.g_cost <= curr_queue_min_key:
                print(f"SOLUTION FOUND at iteration {iterations}!", file=self.writer)
                print(
                    f"Goal g-cost: {self.goal.g_cost:.6f}, queue min key: {curr_queue_min_key:.6f}",
                    file=self.writer,
                )
                path = self.get_path_to_node(self.goal)
                print(f"Path length: {len(path)} points", file=self.writer)
                return path  # terminate, found a bounded solution
            else:
                curr_state = self.OPEN[index].dequeue_min().get_value()
                curr_state.current_open_queues[index] = None

                # Calculate distances to understand search progress
                dist_to_start = self.calculate_euclidean_distance(
                    curr_state.real_coords, self.start.real_coords
                )
                dist_to_goal = self.calculate_euclidean_distance(
                    curr_state.real_coords, self.goal.real_coords
                )

                if show_progress:  # Show distance progress every 5000 iterations
                    print(
                        f"Iter {iterations}: dist_to_goal={dist_to_goal:.6f}, dist_from_start={dist_to_start:.6f}, g-cost={curr_state.g_cost:.6f}",
                        file=self.writer,
                    )

                if self.OPEN[index].m_size == 0:
                    self.non_empty_queues.remove(index)

                self.expand(curr_state, index, show_details)
                r = self.heuristic_resolution(index)
                curr_state.expanded_from_queue[r] = True

        # Debug: Why did we exit the loop?
        print(f"EXITED MAIN LOOP:", file=self.writer)
        print(f"  Final iterations: {iterations}", file=self.writer)
        print(
            f"  Final non_empty_queues length: {len(self.non_empty_queues)}",
            file=self.writer,
        )
        print(
            f"  Final non_empty_queues content: {list(self.non_empty_queues)}",
            file=self.writer,
        )
        print(f"  max_iterations: {max_iterations}", file=self.writer)
        print(
            f"  Reached max iterations: {iterations >= max_iterations}",
            file=self.writer,
        )
        print(f"  Queues empty: {len(self.non_empty_queues) == 0}", file=self.writer)

        if iterations >= max_iterations:
            print(
                f"SEARCH LIMIT REACHED: {max_iterations} iterations", file=self.writer
            )
        else:
            print("ERROR: No path found - all queues empty", file=self.writer)

        return None
