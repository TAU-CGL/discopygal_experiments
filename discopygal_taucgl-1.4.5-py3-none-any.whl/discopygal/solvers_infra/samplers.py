import random
import math

from ..bindings import Point_2, FT
from ..geometry_utils.bounding_boxes import calc_scene_bounding_box
from ..solvers_infra.operations_counter import OperationsCounter

class Sampler(object):
    """
    Abstract class for sampling methods in the scene.

    :param scene: a scene to sample in
    :type scene: :class:`~discopygal.solvers_infra.Scene`
    """
    def __init__(self, scene=None):
        self.scene = scene
        if self.scene is not None:
            self.set_scene(self.scene)

    def set_scene(self, scene):
        """
        Set the scene the sampler should use.
        Can be overridded to add additional processing.

        :param scene: a scene to sample in
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        self.scene = scene
    
    def sample(self):
        """
        Return a sample in the space (might be invalid)

        :return: sampled point
        :rtype: :class:`~discopygal.bindings.Point_2`
        """
        return None


class Sampler_Uniform(Sampler):
    """
    Uniform sampler in the scene

    :param scene: a scene to sample in
    :type scene: :class:`~discopygal.solvers_infra.Scene`
    """
    def __init__(self, scene=None):
        super().__init__(scene)
        if scene is None:
            self.min_x, self.max_x, self.min_y, self.max_y = None, None, None, None # remember scene bounds

    def set_bounds_manually(self, min_x, max_x, min_y, max_y):
        """
        Set the sampling bounds manually (instead of supplying a scene)
        Bounds are given in CGAL :class:`~discopygal.bindings.FT`
        """
        self.min_x, self.max_x, self.min_y, self.max_y = min_x, max_x, min_y, max_y

    def set_scene(self, scene, bounding_box=None):
        """
        Set the scene the sampler should use.
        Can be overridded to add additional processing.

        :param scene: a scene to sample in
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        super().set_scene(scene)
        self.min_x, self.max_x, self.min_y, self.max_y = bounding_box or calc_scene_bounding_box(self.scene)

    @OperationsCounter.count_calls()
    def sample(self):
        """
        Return a sample in the space (might be invalid)

        :return: sampled point
        :rtype: :class:`~discopygal.bindings.Point_2`
        """
        x = random.uniform(self.min_x.to_double(), self.max_x.to_double())
        y = random.uniform(self.min_y.to_double(), self.max_y.to_double())
        return Point_2(FT(x), FT(y))

class SamplerWithAngle(Sampler_Uniform):
    """
    Uniform sampler of random point and angle (for rotation)
    """

    def sample(self):
        """
        Return a sample (point + angle) in the space (might be invalid)

        :return: sampled point, sampled angle
        :rtype: (:class:`~discopygal.bindings.Point_2`, :class:`~discopygal.bindings.FT`)
        """
        return (super().sample(), FT(random.random() * 2 * math.pi))
