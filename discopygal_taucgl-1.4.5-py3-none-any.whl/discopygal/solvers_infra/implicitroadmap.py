from ..geometry_utils import collision_detection, conversions
from ..bindings import Segment_2
from ..solvers_infra import Scene
from ..solvers_infra.metrics import Metric


class ImplicitRoadmap:
    """
    | A class that implicitly represents a roadmap,
    | We don't actually save all of the nodes and edges in memory but only check if they are valid.

    | All points in that are checked for validity are from type :class:`~discopygal.bindings.Point_d`
    | This means they are all :class:`~discopygal.bindings.Point_d` where d is: (dimension of a single robot point) * (number of robots)

    :param scene: the scene of the roadmap
    :type scene: :class:`~discopygal.solvers_infra.Scene`
    :param metric: Metric to use
    :type metric: :class:`~discopygal.solvers_infra.metric.Metric`
    """

    def __init__(self, scene: Scene, metric: Metric):
        self.scene = scene
        self.metric = metric
        self.robots = scene.robots

        # Build collision detection for each robot
        self.collision_detection = {
            robot: collision_detection.ObjectCollisionDetection(scene.obstacles, robot)
            for robot in self.robots
        }

    def is_point_valid(self, point):
        """
        Is a given point valid on the implicit roadmap is a valid point (no collisions)

        :param point: point to check
        :type point: :class:`~discopygal.bindings.Point_d`

        :return: True/False
        :rtype: :class:`bool`
        """
        for i, p in enumerate(conversions.Point_d_to_Point_2_list(point)):
            if not self.collision_detection[self.robots[i]].is_point_valid(p):
                return False
        return True

    def is_edge_valid(self, p, q):
        """
        Get two points in the configuration space and decide if they can be connected -
        i.e. all continuous points from the the source to the dest are collision free.

        :param p: Start point
        :type p: :class:`~discopygal.bindings.Point_d`
        :param q: End point
        :type q: :class:`~discopygal.bindings.Point_d`

        :return: Can they be connected
        :rtype: :class:`bool`
        """
        if p == q:
            return False

        p_list = conversions.Point_d_to_Point_2_list(p)
        q_list = conversions.Point_d_to_Point_2_list(q)

        # Check validity of each edge separately
        for i, robot in enumerate(self.robots):
            edge = Segment_2(p_list[i], q_list[i])
            if not self.collision_detection[robot].is_edge_valid(edge):
                return False

        # Check validity of coordinated robot motion
        for i, robot1 in enumerate(self.robots):
            for j, robot2 in enumerate(self.robots):
                if j <= i:
                    continue
                edge1 = Segment_2(p_list[i], q_list[i])
                edge2 = Segment_2(p_list[j], q_list[j])
                if collision_detection.collide_two_robots(robot1, edge1, robot2, edge2):
                    return False

        return True
