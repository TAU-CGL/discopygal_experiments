import sys
from abc import abstractmethod
import networkx as nx

from ..geometry_utils.bounding_boxes import calc_scene_bounding_box, BoundingBox
from ..solvers_infra import Scene
from ..solvers_infra.operations_counter import OperationsCounter
from ..bindings import Point_2, FT


class Solver(object):
    """
    The main solver class. Every implemented solver should derive from it.

    :param bounding_margin_width_factor:
                                         | The factor which by to increase the solver's bounding box margin
                                         | Set :token:`0` for a tight bounding box
                                         | Set :token:`-1` for no bounding box (default)

    :type bounding_margin_width_factor: :class:`~discopygal.bindings.FT`

    :param scene: The loaded scene object the solver will solve
    :type scene: :class:`~.discopygal.solvers_infra.Scene`

    :param verbose: Should solver print logs during solving process
    :type verbose: :class:`bool`
    """
    DEFAULT_BOUNDS_MARGIN_FACTOR = 2
    NO_BOUNDING_BOX = -1

    def __init__(self, bounding_margin_width_factor=NO_BOUNDING_BOX, **kwargs):
        self.scene = None
        self.writer = None
        self.verbose = kwargs.get("verbose", False)
        self.bounding_margin_width_factor = bounding_margin_width_factor
        self._bounding_box = None
        self.operations_counter = OperationsCounter
        self.operations_counter.clear()

    @classmethod
    def init_solver(cls, **solver_args):
        """
        | Create a solver of given solver class with parameters given in args (as keyword arguments)
        | Each argument is casted according to it's type in :func:`get_arguments`.
        | Also for every argument that isn't given in args, the default value from :func:`get_arguments` is set.
        """
        for arg, (_, default_value, arg_type) in cls.get_arguments().items():
            solver_args[arg] = arg_type(solver_args.get(arg, default_value))
        return cls(**solver_args)

    @classmethod
    def init_default_solver(cls):
        """
        Create a solver with default parameters of given solver class
        """
        return cls.init_solver()

    def __str__(self):
        return self.__class__.__name__

    def load_scene(self, scene: Scene):
        """
        | Load a scene into the solver.
        | Derived solvers can override this method to also add some sort of pre-processing to the scene.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        self.scene = scene
        self._bounding_box = self.calc_bounding_box()

    @abstractmethod
    def _solve(self):
        """
        The actual motion planning algorithm.

        | This is the function that every solver must override and implement it's algorithm.
        | May assume that the scene if already loaded and is at :token:`self.scene`.

        :return: path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        raise NotImplementedError()

    def solve(self, scene=None):
        """
        | Based on the start and end locations of each robot, solve the scene
        | (i.e. return paths for all the robots)
        | Do not override this function! (override :func:`_solve`)

        | This function is the exported function that should be used outside of the solver class to make the solver object to solve.
        | If parameter :token:`scene` is given it first loads it with :func:`load_scene` and then solves it.
        | Otherwise solves again the already pre-loaded scene (if no scene was already loaded it fails)

        :param scene: scene to solve
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        :return: path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        if scene is not None:
            self.load_scene(scene)

        assert self.scene
        path_collection_solution = self._solve()
        if self.verbose:
            self.analyze_solution(path_collection_solution)
        return path_collection_solution

    def analyze_solution(self, path_collection):
        """
        | Print info about the found solution - path_collection.
        | Prints: distance of path of each robot, total distance of all paths (sum of all paths) and makespan

        :param path_collection: The path_collection to print info for
        :type path_collection: :class:`~discopygal.solvers_infra.PathCollection`
        """
        if path_collection is None or path_collection.is_empty():
            self.log('No path found...')
            return

        self.log('Successfully found a path')

        for i, path in enumerate(path_collection.paths.values()):
            start = path.get_points()[0]
            end = path.get_points()[-1]
            path_length = path.calculate_length()
            self.log(f'Path length of robot {i}: {path_length} (air dist: {path_collection.metric.dist(start, end)})')
        self.log(f"Total time of motion (makespan): {path_collection.get_make_span()}")
        self.log(f"Paths lengths sum: {path_collection.get_paths_length_sum()}")

    def set_verbose(self, writer=None):
        """
        Call this method to set a verbose solver, i.e. print while solving.
        """
        self.verbose = True
        self.writer = writer
        if self.writer is None:
            self.writer = sys.stdout

    def disable_verbose(self):
        """
        Call this method to disable verbose running for the solver
        """
        self.writer = None
        self.verbose = False

    def get_graph(self):
        """
        Return a graph (if applicable).
        Can be overridded by solvers.

        :return: graph whose vertices are Point_2 or Point_d
        :rtype: :class:`networkx.Graph` or None
        """
        return None

    def get_arrangement(self):
        """
        | Return an arrangement (if applicable).
        | Can be overridded by solvers.
        | When dispalying the arrangement faces with data >= 0 will be colored green and faces with data < 0 will be colored red.

        :return: arrengement
        :rtype: :class:`~discopygal.bindings.Arrangement_2`
        """
        return None

    def get_bounding_box_graph(self):
        """
        Return the graph of the bounding box the solver calculated for the loaded scene (if used one)

        :return: bounding_box_graph
        :rtype: :class:`networkx.Graph` or None
        """
        if self._bounding_box is None:
            return None

        bounding_box_graph = nx.Graph()
        left_bottom =  Point_2(self._bounding_box.min_x, self._bounding_box.min_y)
        left_top =     Point_2(self._bounding_box.min_x, self._bounding_box.max_y)
        right_bottom = Point_2(self._bounding_box.max_x, self._bounding_box.min_y)
        right_top =    Point_2(self._bounding_box.max_x, self._bounding_box.max_y)
        for point in [left_bottom, left_top, right_bottom, right_top]:
            bounding_box_graph.add_node(point)

        bounding_box_graph.add_edge(left_bottom, left_top)
        bounding_box_graph.add_edge(left_top, right_top)
        bounding_box_graph.add_edge(right_top, right_bottom)
        bounding_box_graph.add_edge(right_bottom, left_bottom)
        return bounding_box_graph

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        return {
            'bounding_margin_width_factor': ('Margin width factor (for bounding box):', 0, FT),
        }

    @classmethod
    def from_arguments(cls, d):
        """
        Get a dictionary of arguments and return a solver.
        Should be overridded by solvers.

        :param d: arguments dict
        :type d: :class:`dict`

        :return: solver object with arguments as in dict d
        :rtype: :class:`Solver`

        .. deprecated:: 1.0.3
            Use :func:`init_default_solver` or :func:`init_solver` instead
        """
        return cls.init_solver(**d)

    def update_arguments(self, args: dict):
        """
        Update the arguments solver

        :param args: arguments dict
        :type args: :class:`dict`
        """
        self.__dict__.update(args)

    def return_arguments(self):
        """
        Return a dict of the solver's arguments with there value

        :rtype: :class:`dict`
        """
        return {arg_name: self.__getattribute__(arg_name) for arg_name in self.get_arguments().keys()}

    def log(self, text, **kwargs):
        """
        | Print a log to screen and to gui is enabled
        | Prints only if set to be verbose (automatically done in solver_viewer)

        :param text: text to print
        :param kwargs: more key-word arguments to pass to :func:`print` builtin function
        """
        if self.verbose:
            print(text, file=self.writer, **kwargs)

    def calc_bounding_box(self):
        if self.scene is None or self.bounding_margin_width_factor < 0:
            return None

        margin_width = self.scene.calc_max_robot_size() * self.bounding_margin_width_factor
        tight_bounding_box = calc_scene_bounding_box(self.scene)
        return BoundingBox(tight_bounding_box.min_x - margin_width,
                           tight_bounding_box.max_x + margin_width,
                           tight_bounding_box.min_y - margin_width,
                           tight_bounding_box.max_y + margin_width)

    def on_gui_load(self, gui, layout):
        """
        Callback that will be called when solver is loaded at Solver Viewer
        """
