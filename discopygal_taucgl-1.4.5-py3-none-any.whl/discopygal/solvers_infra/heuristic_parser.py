from math import sqrt
from enum import Enum


class HeuristicType(Enum):
    EUCLIDEAN = "euclidean"
    INDIVIDUAL_SUM = "individual_sum"
    MANHATTAN = "manhattan"
    MAX_ROBOT = "max_robot"

    def create_heuristic(self, goal_coords):
        """
        Create a heuristic function for this heuristic type.

        :param goal_coords: Goal coordinates in configuration space
        :type goal_coords: :class:`~discopygal.bindings.Point_d`
        :return: Heuristic function
        :rtype: callable
        """

        def heuristic_function(coords, goal=goal_coords):
            """Dynamic heuristic function based on enum type."""
            if self == HeuristicType.EUCLIDEAN:
                # Simple euclidean distance between Point_d objects
                # TODO: check if we should use this or the c++ approach, im not sure
                # for i in range(0,coords.dimension(),2):
                # diff_x = float(coords[i]) - float(goal[i])
                # diff_y = float(coords[i+1]) - float(goal[i+1])
                # distance += sqrt(diff_x * diff_x + diff_y * diff_y)
                # return distance
                distance = 0.0
                for i in range(coords.dimension()):
                    diff = float(coords[i]) - float(goal[i])
                    distance += diff * diff
                return sqrt(distance)

            elif self == HeuristicType.INDIVIDUAL_SUM:
                # Sum of individual robot distances to their goals
                total_distance = 0.0
                num_robots = coords.dimension() // 2
                for robot_i in range(num_robots):
                    robot_x = float(coords[robot_i * 2])
                    robot_y = float(coords[robot_i * 2 + 1])
                    goal_x = float(goal[robot_i * 2])
                    goal_y = float(goal[robot_i * 2 + 1])
                    robot_dist = sqrt((robot_x - goal_x) ** 2 + (robot_y - goal_y) ** 2)
                    total_distance += robot_dist
                return total_distance

            elif self == HeuristicType.MANHATTAN:
                # L1 distance - sum of absolute differences
                total = 0.0
                for i in range(coords.dimension()):
                    total += abs(float(coords[i]) - float(goal[i]))
                return total

            elif self == HeuristicType.MAX_ROBOT:
                # Maximum individual robot distance (makespan estimate)
                max_distance = 0.0
                num_robots = coords.dimension() // 2
                for robot_i in range(num_robots):
                    robot_x = float(coords[robot_i * 2])
                    robot_y = float(coords[robot_i * 2 + 1])
                    goal_x = float(goal[robot_i * 2])
                    goal_y = float(goal[robot_i * 2 + 1])
                    robot_dist = sqrt((robot_x - goal_x) ** 2 + (robot_y - goal_y) ** 2)
                    max_distance = max(max_distance, robot_dist)
                return max_distance

            else:
                raise ValueError(f"Unknown heuristic type: {self}")

        return heuristic_function

    @classmethod
    def from_string(cls, heuristic_name):
        """
        Get HeuristicType from string name.

        :param heuristic_name: String name of the heuristic
        :type heuristic_name: str
        :return: HeuristicType enum member
        :rtype: HeuristicType
        :raises ValueError: If heuristic name is not recognized
        """
        for heuristic_type in cls:
            if heuristic_type.value == heuristic_name:
                return heuristic_type
        raise ValueError(f"Unknown heuristic type: {heuristic_name}")


class HeuristicParser:
    """
    Utility class for parsing string heuristic names into actual heuristic functions.

    This class provides a centralized way to convert heuristic function names
    (like "euclidean", "manhattan", etc.) into actual callable functions for
    lattice-based solvers.
    """

    @staticmethod
    def parse_heuristics(heuristics_dict, goal_coords, logger=None):
        """
        Parse a dictionary of heuristic names into actual heuristic functions.

        :param heuristics_dict: Dictionary mapping indices to (heuristic_name, resolution) pairs
        :type heuristics_dict: :class:`dict`
        :param goal_coords: Goal coordinates in configuration space
        :type goal_coords: :class:`~discopygal.bindings.Point_d`
        :param logger: Optional logger function for debug output
        :type logger: callable or None

        :return: Dictionary with same keys but heuristic names replaced with actual functions
        :rtype: :class:`dict`
        """
        parsed_heuristics = {}

        if logger:
            logger("Converting heuristics...")

        for key, (hfunc, resolution) in heuristics_dict.items():
            if logger:
                logger(f"  Heuristic {key}: {hfunc} with resolution {resolution}")

            # Check if hfunc is a string that matches a known heuristic type
            if isinstance(hfunc, str):
                try:
                    heuristic_type = HeuristicType.from_string(hfunc)
                    heuristic_function = heuristic_type.create_heuristic(goal_coords)
                    parsed_heuristics[key] = (heuristic_function, resolution)
                except ValueError:
                    # Unknown string heuristic name
                    if logger:
                        logger(f"  Warning: Unknown heuristic '{hfunc}', keeping as-is")
                    parsed_heuristics[key] = (hfunc, resolution)
            else:
                # If hfunc is already a function, keep it as is
                parsed_heuristics[key] = (hfunc, resolution)

        return parsed_heuristics
