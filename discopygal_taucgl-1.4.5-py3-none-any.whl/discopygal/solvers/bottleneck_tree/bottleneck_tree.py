import abc
import random
import networkx as nx
import numpy as np

from discopygal.solvers_infra import PathCollection, PathPoint, Path
from discopygal.solvers_infra.SamplingSolver import SamplingSolver
from discopygal.solvers.prm import PRM
from discopygal.solvers.staggered_grid.staggered_grid import StaggeredGrid
from discopygal.solvers.rrt.rrt_star import RRT_star
from discopygal.bindings import Point_d, FT
from discopygal.geometry_utils import conversions
from discopygal.solvers_infra.metrics import Metric_Euclidean
from discopygal.solvers_infra.nearest_neighbors import NearestNeighborsCached, NearestNeighbors_sklearn
from discopygal.solvers import get_solver_class


class BottleneckTree(SamplingSolver):
    def __init__(self, num_landmarks_in_parameter_space, radius, solver_class, avoid_collisions, **kwargs):
        self.num_landmarks_in_parameter_space = num_landmarks_in_parameter_space
        self.radius = radius
        self.solver_class = solver_class
        self.avoid_collisions = avoid_collisions
        super().__init__(**kwargs)

    @classmethod
    def get_arguments(cls):
        def to_bool(text):
            return bool(eval(text))

        args = {
            'num_landmarks_in_parameter_space': ('Number of Landmarks in parameter space:', 200, int),
            'radius': ('Connection radius in parameter space:', 0.5, FT),
            'solver_class': ('Solver algorithm for paths:', 'PRM', str),
            'avoid_collisions': ('Should avoid collisions:', "False", to_bool),
        }
        args.update(super().get_arguments())
        return args

    @abc.abstractmethod
    def cost_map(self, point):
        raise NotImplementedError()

    def fraction_point_in_segment(self, p, q, frac):
        start = np.array(list(p.cartesians()))
        end = np.array(list(q.cartesians()))
        return Point_d(self.d, list(start + (end - start) * frac))

    def cost_map_edge(self, p, q):
        costs = []
        for frac in np.linspace(0, 1, 100):
            step_point = self.fraction_point_in_segment(p, q, frac)
            costs.append(self.cost_map(step_point))
        return max(costs)

    def sample_point_in_parameter_space(self):
        return Point_d(self.d, [random.random() for _ in range(self.d)])

    def generate_original_paths(self):
        if self.solver_class == "straight":
            path_collection = PathCollection()
            for robot in self.scene.robots:
                path_collection.add_robot_path(robot, Path.path_from_points([robot.start, robot.end]))
            return path_collection

        solver_class = get_solver_class(self.solver_class)
        if solver_class is None:
            self.log("Error: Solver class doens't exist")
            return PathCollection()
        path_collection = solver_class.init_solver(verbose=True).solve(self.scene)
        self.analyze_solution(path_collection)
        return path_collection

    def build_roadmap(self):
        self.d = len(self.scene.robots)
        self.original_path_collection = self.generate_original_paths()
        self.roadmap = self.init_roadmap()
        if self.original_path_collection.is_empty():
            return self.roadmap

        paths = [self.original_path_collection.paths[self.scene.robots[i]].get_points() for i in range(self.d)]
        path_points = [
            conversions.Point_2_list_to_Point_d([paths[j][i] for j in range(self.d)])
            for i in range(len(paths[0]))
        ]
        self.roadmap.add_point(path_points[0])
        for i in range(1, len(path_points)):
            self.roadmap.add_point(path_points[i])
            self.roadmap.add_edge(path_points[i-1], path_points[i], check_if_valid=False)
        return self.roadmap

    def search_path_on_roadmap(self):
        if self.original_path_collection.is_empty():
            return self.original_path_collection

        self.parameter_start = Point_d(self.d, [0] * self.d)
        self.parameter_end = Point_d(self.d, [1] * self.d)
        self.parameter_space = nx.Graph()
        parameter_space_metric = Metric_Euclidean()
        parameter_space_nn = NearestNeighborsCached(NearestNeighbors_sklearn(), self.num_landmarks_in_parameter_space)

        # Add start and end locations
        self.parameter_space.add_node(self.parameter_start)
        self.parameter_space.add_node(self.parameter_end)

        # Add valid points
        for i in range(self.num_landmarks_in_parameter_space):
            if self.avoid_collisions:
                sampled_point = None
                while sampled_point is None or not self.roadmap.is_point_valid(point_in_config_space):
                    sampled_point = self.sample_point_in_parameter_space()
                    point_in_config_space = self.point_in_parameter_space_to_point_in_config_space(sampled_point)
            else:
                sampled_point = self.sample_point_in_parameter_space()

            self.parameter_space.add_node(sampled_point)
            if i % 100 == 0:
                self.log(f'added {i} landmarks in Bottleneck Tree roadmap')

        parameter_space_nn.fit(list(self.parameter_space.nodes))

        def check_collisions_in_parameter_edge(p, q):
            p_cartesians = [x for x in p.cartesians()]
            q_cartesians = [x for x in q.cartesians()]
            check_points = [Point_d(self.d, list(point)) for point in np.linspace(p_cartesians, q_cartesians, 10, endpoint=True)]
            return all([
                self.roadmap.is_edge_valid(self.point_in_parameter_space_to_point_in_config_space(check_points[i]),
                                           self.point_in_parameter_space_to_point_in_config_space(check_points[i+1]))
                for i in range(len(check_points) - 1)
            ])

        for i, p in enumerate(self.parameter_space):
            self.log(f"Connected {i+1}/{len(self.parameter_space)}")
            for q in parameter_space_nn.nearest_in_radius(p, self.radius):
                if not self.parameter_space.has_edge(p, q) and \
                   (not self.avoid_collisions or check_collisions_in_parameter_edge(p, q)):
                    self.parameter_space.add_edge(p, q, weight=parameter_space_metric.dist(p, q))

        self.costs = {p: float('inf') for p in self.parameter_space}
        self.parents = {p: None for p in self.parameter_space}
        self.costs[self.parameter_start] = self.cost_map(self.parameter_start)

        while self.parameter_space.number_of_nodes() > 0:
            self.log(f"Number of nodes left: {self.parameter_space.number_of_nodes()}")
            z = self.get_smallest_point()
            if self.costs[z] == float('inf'):
                return PathCollection()

            if z == self.parameter_end:
                break

            neighbors = self.parameter_space.neighbors(z)
            for neighbor in neighbors:
                if self.is_monotone(z, neighbor) and self.costs[z] < self.costs[neighbor]:
                    new_cost = max([self.costs[z], self.cost_map_edge(z, neighbor)])
                    if new_cost < self.costs[neighbor]:
                        self.costs[neighbor] = new_cost
                        self.parents[neighbor] = z
            self.parameter_space.remove_node(z)

        parameter_path = self.traverse_path_back(self.parameter_end)
        self.log(f"Parameter path {parameter_path}")
        return self.create_final_paths(parameter_path)

    def traverse_path_back(self, v):
        if v == self.parameter_start:
            return [v]
        else:
            return self.traverse_path_back(self.parents[v]) + [v]

    def get_smallest_point(self):
        return min(self.parameter_space.nodes, key=lambda v: self.costs[v])

    def is_monotone(self, p, q):
        assert p.dimension() == q.dimension()
        return all([p.cartesian(i) <= q.cartesian(i) for i in range(p.dimension())])

    # def segment_index_of_point_in_path(self, robot_index, fraction):
    #     robot = self.scene.robots[robot_index]
    #     absolute_length = self.original_path_collection.get_path_length(robot) * fraction
    #     path_points = [conversions.Point_2_to_Point_d(p) for p in self.original_path_collection.paths[robot].get_points()]
    #     i = 0

    #     current_dist = self.metric.dist(path_points[i], path_points[i+1])
    #     while absolute_length > current_dist:
    #         i += 1
    #         absolute_length -= current_dist
    #         current_dist = self.metric.dist(path_points[i], path_points[i+1])

    #     while i+1 < len(path_points) and path_points[i] == path_points[i+1]:
    #         i += 1

    #     return i

    # def fraction_in_path_to_point(self, robot_index, fraction):
    #     robot = self.scene.robots[robot_index]
    #     segment_index = self.segment_index_of_point_in_path(robot_index, fraction)
    #     absolute_length = self.original_path_collection.get_path_length(robot) * fraction
    #     path_points = [conversions.Point_2_to_Point_d(p) for p in self.original_path_collection.paths[robot].get_points()]

    #     absolute_length -= self.original_path_collection.paths[robot].get_dist_from_start_to_point(segment_index)
    #     return conversions.Point_d_to_Point_2(self.fraction_point_in_segment(path_points[segment_index], path_points[segment_index+1], absolute_length / self.metric.dist(path_points[segment_index], path_points[segment_index+1])))

    def fraction_to_point_of_robot_path(self, robot_index, fraction):
        return self.original_path_collection.paths[self.scene.robots[robot_index]].point_of_fraction(fraction)
        # return self.original_path_collection.points_of_time(fraction * self.original_path_collection.get_make_span())[robot_index]

    def point_index_to_fraction_of_robot_path(self, robot, point_index):
        return self.original_path_collection.paths[robot].get_dist_from_start_to_point(point_index) / self.original_path_collection.get_path_length(robot)
        # return self.original_path_collection.get_time_from_start_to_point(point_index) / self.original_path_collection.get_make_span()

    def create_final_paths(self, parameter_path):
        paths = {}
        for robot_index, robot in enumerate(self.scene.robots):
            path_points = []
            for point in parameter_path:
                fraction = point.cartesian(robot_index)
                path_points.append(PathPoint(self.fraction_to_point_of_robot_path(robot_index, fraction),
                                   data={"fraction": fraction, "is_parameter_point": True}))

            parameter_points = [p.location for p in path_points]
            for i, point in enumerate(self.original_path_collection.paths[robot].points):
                if point.location in parameter_points:
                    continue

                path_points.append(PathPoint(point.location,
                                   data={"fraction": self.point_index_to_fraction_of_robot_path(robot, i),
                                         "is_parameter_point": False}))

            path_points = sorted(path_points, key=lambda point: point.data['fraction'])
            paths[robot] = Path(path_points)

        points_to_parameter_point = [0] * len(parameter_path)
        for robot_index, path in enumerate(paths.values()):
            parameter_point_index = 0
            num_of_points = 0
            for point in path.points:
                num_of_points += 1
                if point.data['is_parameter_point']:
                    if num_of_points > points_to_parameter_point[parameter_point_index]:
                        points_to_parameter_point[parameter_point_index] = num_of_points
                    parameter_point_index += 1
                    num_of_points = 0

        for robot_index, path in enumerate(paths.values()):
            robot = self.scene.robots[robot_index]
            new_path_points = []
            parameter_point_index = 0
            num_of_points = 0
            for i, point in enumerate(path.points):
                num_of_points += 1
                new_path_points.append(point)

                if point.data['is_parameter_point']:
                    if parameter_point_index > 0:
                        # print(f"prev_para_point={i - num_of_points}, current_para_point={i}, fill={points_to_parameter_point[parameter_point_index]-num_of_points}")
                        for fraction in np.linspace(float(path.get_dist_from_start_to_point(i - num_of_points) / path.calculate_length()),
                                                    float(path.get_dist_from_start_to_point(i) / path.calculate_length()),
                                                    points_to_parameter_point[parameter_point_index] - num_of_points + 1,
                                                    endpoint=False)[1:]:
                            new_path_points.append(PathPoint(self.fraction_to_point_of_robot_path(robot_index, fraction),
                                                             data={"fraction": fraction, "is_parameter_point": False}))

                    parameter_point_index += 1
                    num_of_points = 0

            path.points = sorted(new_path_points, key=lambda point: point.data['fraction'])

        for path in paths.values():
            for i, point in enumerate(path.points[:-1]):
                point.data['speed'] = path.segment_length(i)
                if point.data['speed'] == 0:
                    point.data['speed'] = 1

        final_path_collection = PathCollection(paths, metric=self.metric)
        return final_path_collection

    def point_in_parameter_space_to_point_in_config_space(self, point_in_parameter_space: Point_d):
        return conversions.Point_2_list_to_Point_d(
            [self.fraction_to_point_of_robot_path(i, point_in_parameter_space.cartesian(i)) for i in range(self.d)])
