import itertools
import numpy as np
from PyQt5 import QtWidgets, QtCore

from discopygal.solvers.bottleneck_tree.bottleneck_tree import BottleneckTree
from discopygal.solvers_infra import PathCollection


class FrechetMatching(BottleneckTree):
    def cost_map(self, point):
        # Frechet matching
        dists = []
        for i, j in itertools.combinations(range(point.dimension()), 2):
            point_i = self.fraction_to_point_of_robot_path(i, point.cartesian(i))
            point_j = self.fraction_to_point_of_robot_path(j, point.cartesian(j))
            dists.append(self.metric.dist(point_i, point_j))
        return max(dists)

    def anti_frechet_cost_map(self, point):
        # Anti Frechet matching
        dists = []
        for i, j in itertools.combinations(range(point.dimension()), 2):
            point_i = self.fraction_to_point_of_robot_path(i, point.cartesian(i))
            point_j = self.fraction_to_point_of_robot_path(j, point.cartesian(j))
            dists.append(self.metric.dist(point_i, point_j))
        return 20 - min(dists)
        # return -1 * min(dists)

    def calc_frechet_distance(self, path_collection: PathCollection):
        distances_per_time = {}
        for time_point in np.linspace(0, float(path_collection.get_make_span()), 10_000):
            robot_points = path_collection.points_of_time(time_point)
            distances_of_pairs = {
                robot_pair: (path_collection.metric.dist(robot_points[robot_pair[0]], robot_points[robot_pair[1]]), robot_points)
                for robot_pair in itertools.combinations(range(len(robot_points)), 2)
            }
            max_pair = max(distances_of_pairs, key=lambda k: distances_of_pairs[k][0])
            distances_per_time[time_point] = (max_pair, *distances_of_pairs[max_pair])

        frechet_dist = max(distances_per_time.items(), key=lambda v: v[1][1])

        # time, pair, dist, robot_points
        return frechet_dist[0], frechet_dist[1][0], frechet_dist[1][1], frechet_dist[1][2]

    def search_path_on_roadmap(self):
        self.final_path_collection = super().search_path_on_roadmap()
        if self.final_path_collection.is_empty():
            return self.final_path_collection

        self.log("Original Frechet distance: time={}, pair={}, dist={}".format(*self.calc_frechet_distance(self.original_path_collection)))
        self.log("Final Frechet distance: time={}, pair={}, dist={}".format(*self.calc_frechet_distance(self.final_path_collection)))
        return self.final_path_collection

    def on_gui_load(self, gui, layout):
        super().on_gui_load(gui, layout)
        show_bottleneck_button = QtWidgets.QPushButton("Show Bottleneck")
        layout.addWidget(show_bottleneck_button)
        show_bottleneck_button.clicked.connect(gui.show_bottleneck_action)

    def show_bottleneck(self, gui):
        if "final_path_collection" not in dir(self) or not self.final_path_collection or self.final_path_collection.is_empty():
            return

        bottleneck_time, bottleneck_pair, dist, robot_points = self.calc_frechet_distance(self.final_path_collection)
        for i, robot in enumerate(gui.scene_drawer.robot_lut.values()):
            robot_gui = robot[0]
            robot_gui.pos = QtCore.QPointF(robot_points[i].x().to_double(), robot_points[i].y().to_double())

        gui.add_visual_edge(robot_points[bottleneck_pair[0]], robot_points[bottleneck_pair[1]],
                            None, "darkMagenta", 1, None, gui.path_edges, line_width=10)

