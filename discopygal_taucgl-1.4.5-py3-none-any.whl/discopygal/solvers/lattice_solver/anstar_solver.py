from discopygal.solvers.lattice_solver.latticebase import Latticebase
from discopygal.solvers_infra.metrics import Metric_Euclidean
from math import sqrt
import numpy as np


class anstar_lattice(Latticebase):
    def __init__(self, eps, delta, resolutions, heuristics, w1, w2, **kwargs):
        if isinstance(resolutions, str):
            resolutions = eval(resolutions)
        if isinstance(heuristics, str):
            if heuristics.strip() == "euclidean":
                heuristics = {0: ("euclidean", 1.0)}  # Use float to match resolutions
            else:
                heuristics = (
                    eval(heuristics) if heuristics.strip() else {0: ("euclidean", 1.0)}
                )

        # Force Euclidean metric for proper D-dimensional distance calculation
        kwargs["metric"] = Metric_Euclidean
        self.anstar_x = None

        super().__init__(eps, delta, resolutions, heuristics, w1, w2, **kwargs)

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            "eps": ("Epsilon:", 1.0, float),
            "delta": ("Delta:", 2.0, float),
            "resolutions": ("Resolutions:", "[1.0, 2.0, 2.5]", str),
            "heuristics": (
                "Heuristics:",
                '{0: ("euclidean", 1.0),1:("euclidean", 2.0), 2: ("individual_sum", 2.0), 3: ("euclidean", 2.5), 4: ("manhattan", 2.5)}',
                str,
            ),
            "w1": ("Weight 1:", 5.0, float),
            "w2": ("Weight 2:", 2.0, float),
        }
        args.update(super().get_arguments())
        return args

    def set_parameters(self):
        # Set AN* specific rescaling and parameters
        self.dim = len(self.scene.robots) * 2
        self.rescale = sqrt((12.0 * (self.dim + 1)) / (self.dim * (self.dim + 2)))
        self.anstar_x = 1.0 / (self.dim + 1 - sqrt(self.dim + 1))

        # Log AN* specific parameter
        self.log(f"ANSTAR X: {self.anstar_x:.6f}")

        # Call base class to handle common setup
        super().set_parameters()

    def create_resolution_generator_matrices(self):
        """Generate matrices for all resolutions"""
        self.log("--- Generating Resolution Matrices ---")

        for resolution in self.resolutions:
            self.log(f"  Processing matrix for resolution {resolution}")
            res_data = self.resolution_data[resolution]
            rescale = res_data.res_rescale
            self.log(f"    Rescale factor: {rescale:.6f}")

            generator_matrix = np.zeros((self.dim, self.dim))

            for j in range(self.dim):
                for w in range(self.dim):
                    if j == 0:
                        if w < self.dim - 1:
                            generator_matrix[j, w] = rescale
                        else:
                            generator_matrix[j, w] = rescale * (self.anstar_x - 1)
                    else:
                        if w == j - 1:
                            generator_matrix[j, w] = -rescale
                        elif w < self.dim - 1:
                            generator_matrix[j, w] = 0
                        else:
                            generator_matrix[j, w] = rescale * self.anstar_x

            # Store the matrix in the resolution data
            res_data.res_generator_matrix = generator_matrix
            res_data.res_inverse_generator_matrix = np.linalg.inv(generator_matrix)

            self.log(f"    Matrix shape: {generator_matrix.shape}")
            self.log(f"    Matrix determinant: {np.linalg.det(generator_matrix):.6f}")
            self.log(f"    Generator Matrix for resolution {resolution}:")
            self.log(f"{generator_matrix}")

        self.log("--- Matrix Generation Complete ---")
