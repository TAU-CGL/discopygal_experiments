from discopygal.solvers_infra.SamplingSolver import SamplingSolver
from discopygal.solvers_infra import Scene, PathCollection, Path
from discopygal.solvers_infra.heuristic_parser import HeuristicParser
from discopygal.solvers_infra.search_algo import Graph
from discopygal.geometry_utils import conversions
from discopygal.bindings import Point_d
from math import sqrt
import numpy as np
from collections import deque


class Neighbor:
    def __init__(self, lattice_offset, real_offset, distance):
        self.lattice_offset = lattice_offset  # numpy array
        self.real_offset = real_offset  # Point_d
        self.distance = distance


class ResolutionData:
    def __init__(self, resolution, dim, eps, delta, beta, rescale):
        self.res_delta = delta * resolution
        self.res_beta = beta * resolution
        self.res_rescale = rescale * self.res_beta
        self.res_connection_radius = 2 * delta * (eps + 1) / sqrt(1 + eps**2)
        self.res_covering_radius = 2 * self.res_delta * (eps + 1)
        self.res_generator_matrix = np.zeros((dim, dim))
        self.res_inverse_generator_matrix = None
        self.neighbors = []  # list of Neighbor objects


class Latticebase(SamplingSolver):
    """
    Base class for lattice-based motion planning solvers.

    This abstract class provides the common interface and basic functionality
    for solvers that use lattice structures for path planning, including
    AN* and staggered grid approaches.

    :param eps: Epsilon parameter for lattice construction
    :type eps: :class:`float`
    :param delta: Delta parameter for lattice spacing
    :type delta: :class:`float`
    :param resolutions: List of resolution values for different lattice levels
    :type resolutions: :class:`list`
    :param heuristics: Dictionary of heuristic functions mapped to resolutions
    :type heuristics: :class:`dict`
    :param w1: Weight for heuristic function in key calculation (inflation factor)
    :type w1: :class:`float`
    :param w2: Weight for queue selection in multi-heuristic search
    :type w2: :class:`float`
    """

    def __init__(self, eps, delta, resolutions, heuristics, w1=1.0, w2=1.0, **kwargs):
        super().__init__(**kwargs)
        self.eps = eps
        self.delta = delta
        self.resolutions = (
            resolutions  ## first one is always 1 - the highest resolution
        )
        self.heuristics = heuristics  ## first is euclidean distance for first resolutiuon {1: euclidean, resolution 1}
        self.sample_method = ""
        self.robot_radius = 0
        self.sources = None
        self.destinations = None
        self.resolution_data = {}
        self.dim = 0
        self.graph = None
        self.w1 = w1
        self.w2 = w2
        self.rescale = None
        self.beta = None
        self.connection_radius = None

    def set_parameters(self):
        """
        Set algorithm-specific parameters.

        Subclasses should set their specific rescale value before calling super().set_parameters()
        """
        self.log("--- Setting Lattice Parameters ---")

        # We are currrently working only with robots with 2 DOF
        self.dim = len(self.scene.robots) * 2  # dimension of the configuration space
        self.log(f"Configuration space dimension: {self.dim}")

        self.beta = (self.delta * self.eps) / sqrt(1 + self.eps**2)
        self.connection_radius = 2 * self.delta * (self.eps + 1) / sqrt(1 + self.eps**2)

        self.log(f"Eps: {self.eps}, Delta: {self.delta}")
        self.log(f"Beta: {self.beta:.6f}")
        self.log(f"Connection radius: {self.connection_radius:.6f}")
        self.log(f"Rescale: {self.rescale:.6f}")

        # Convert string heuristic names to actual functions using the parser
        self.heuristics = HeuristicParser.parse_heuristics(
            self.heuristics, self.end, logger=self.log
        )

        self.log(f"Processing {len(self.resolutions)} resolutions: {self.resolutions}")

        for resolution in self.resolutions:
            self.log(f"  Creating ResolutionData for resolution {resolution}")
            self.resolution_data[resolution] = ResolutionData(
                resolution, self.dim, self.eps, self.delta, self.beta, self.rescale
            )
            res_data = self.resolution_data[resolution]
            self.log(
                f"    Resolution {resolution}: res_delta={res_data.res_delta:.6f}, res_connection_radius={res_data.res_connection_radius:.6f}"
            )

        self.log("Creating generator matrices...")
        self.create_resolution_generator_matrices()

        for resolution in self.resolutions:
            self.log(f"  Generating neighbors for resolution {resolution}...")
            self.resolution_data[resolution].neighbors = self.generate_neighbors(
                resolution
            )
            neighbor_count = len(self.resolution_data[resolution].neighbors)
            self.log(f"  Found {neighbor_count} neighbors for resolution {resolution}")

        self.log("Creating Lattice Graph...")
        self.graph = Graph(
            self.start,
            self.end,
            self.dim,
            self.connection_radius,
            self.w1,
            self.w2,
            self.heuristics,
            self.resolution_data,
            self.metric,
            self.writer,
            self.scene,
        )
        self.log("Graph created successfully")
        self.log("--- Parameter Setting Complete ---")

    def create_resolution_generator_matrices(self):
        """
        Create generator matrices for different resolution levels.

        This method should be overridden by concrete implementations to generate
        the transformation matrices used for lattice point generation.
        """
        pass

    def generate_neighbors(self, resolution):
        """
        Generate neighbors offsets for a given resolution.
        we don't care in this part  about validity og the neighbors, only about lattice structue
        and if we stay inside the search radius.

        :return: List of neighbor offsets (real coords, lattice coords, distance) based on
        lattice structure and search radius.
        :rtype: list of Neighbor objects
        """

        connection_radius = self.resolution_data[resolution].res_connection_radius

        self.log(
            f"    NEIGHBOR GEN DEBUG: resolution={resolution}, connection_radius={connection_radius:.6f}"
        )
        current_wave = deque()
        next_wave = deque()
        visited_counts = {}  # Track how many times we've seen each lattice point
        neighbor_offsets = []

        # Start at lattice origin - convert CGAL Point_d to numpy
        root_real_coords = np.array(
            [self.start[i] for i in range(self.start.dimension())]
        )
        root_lattice_coords = np.zeros(self.dim, dtype=int)

        current_wave.append((root_real_coords, root_lattice_coords, 0.0))
        visited_counts[tuple(root_lattice_coords)] = 0

        # Debug the actual lattice step sizes
        sample_step = (
            self.resolution_data[resolution].res_generator_matrix[:, 0] * resolution
        )
        step_size = np.linalg.norm(sample_step)
        self.log(
            f"    Sample lattice step size: {step_size:.6f}, connection radius {connection_radius:.6f})"
        )

        wave_count = 0
        nodes_processed = 0
        within_radius_count = 0
        outside_radius_count = 0

        while current_wave or next_wave:
            # Move to next BFS wave if current is empty
            if not current_wave:
                current_wave = next_wave
                next_wave = deque()
                wave_count += 1

                self.log(
                    f"    BFS Wave {wave_count}: {len(neighbor_offsets)} neighbors found, {nodes_processed} nodes processed"
                )

            # Process current node
            curr_real_coords, curr_lattice_coords, curr_cost = current_wave.popleft()
            nodes_processed += 1

            # Explore all lattice directions from current node
            sign = -1
            for _ in range(2):
                sign *= -1
                for i in range(self.dim):
                    # Calculate new lattice coordinates
                    new_lattice_coords = curr_lattice_coords.copy()
                    new_lattice_coords[i] += sign

                    # Convert to continuous position using generator matrix
                    lattice_step = self.resolution_data[
                        resolution
                    ].res_generator_matrix[
                        :, i
                    ]  # col i of the generator matrix
                    new_real_coords = curr_real_coords + sign * lattice_step

                    # Check visit count to avoid infinite loops
                    coords_key = tuple(new_lattice_coords)
                    max_visits = (
                        2 * self.dim
                    )  # Each point can be reached from 2*d directions

                    if (
                        coords_key in visited_counts
                        and visited_counts[coords_key] < max_visits
                    ):
                        visited_counts[coords_key] += 1
                        if visited_counts[coords_key] == max_visits:
                            del visited_counts[coords_key]  # Fully explored

                    else:  # coords_key not in visited_counts:
                        # New lattice point - check if within radius
                        visited_counts[coords_key] = 1
                        # Calculate distance using numpy
                        distance = np.linalg.norm(new_real_coords - root_real_coords)

                        if (
                            distance
                            <= self.resolution_data[resolution].res_connection_radius
                        ):
                            within_radius_count += 1
                            # Convert back to CGAL Point_d for neighbor offset
                            offset_vector = (
                                new_real_coords - root_real_coords
                            )  # Calculate the real offset
                            offset_point_d = Point_d(
                                len(offset_vector), offset_vector.tolist()
                            )  # Convert offset to Point_d

                            # Store this neighbor offset (actual offset, not absolute position)
                            neighbor_offset = Neighbor(
                                new_lattice_coords, offset_point_d, distance
                            )
                            neighbor_offsets.append(neighbor_offset)

                            # Add to next wave for further exploration (keep as numpy)
                            next_wave.append(
                                (new_real_coords, new_lattice_coords, distance)
                            )
                        else:
                            outside_radius_count += 1

        self.log(
            f"    Final: {len(neighbor_offsets)} neighbors, {nodes_processed} nodes processed, {wave_count} waves"
        )
        self.log(
            f"    Within radius: {within_radius_count}, Outside radius: {outside_radius_count}"
        )

        return neighbor_offsets

    def load_scene(self, scene: Scene):
        """
        Load a scene into the lattice solver.

        This method performs the common scene loading operations for lattice-based solvers:
        - Sets up the scene and bounding box
        - Configures the sampler
        - Converts robot coordinates to configuration space representation
        - Calls set_parameters() to initialize solver-specific parameters

        :param scene: scene to load
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        self.log(f"=== {self.__class__.__name__} SOLVER - Loading Scene ===")
        self.log(f"Scene: {len(scene.robots)} robots, {len(scene.obstacles)} obstacles")

        # set start and end, scene, bounding box
        self.scene = scene
        self._bounding_box = self.calc_bounding_box()

        self.sampler.set_scene(scene, self._bounding_box)

        # Log the conversion input
        start_list = [robot.start for robot in scene.robots]
        end_list = [robot.end for robot in scene.robots]
        self.log(f"Point_2 list for start: {start_list}")
        self.log(f"Point_2 list for end: {end_list}")

        self.start = conversions.Point_2_list_to_Point_d(
            [robot.start for robot in scene.robots]
        )
        self.end = conversions.Point_2_list_to_Point_d(
            [robot.end for robot in scene.robots]
        )
        self.log(
            f"  Start Point_d: {[self.start[i] for i in range(self.start.dimension())]}"
        )
        self.log(f"  End Point_d: {[self.end[i] for i in range(self.end.dimension())]}")

        self.log(f"Configuration space dimension: {self.start.dimension()}")

        self.log("Calling set_parameters()...")
        self.set_parameters()
        self.log("=== Scene Loading Complete ===")

    def get_graph(self):
        return self.graph

    def _solve(self):
        return self.search_path_on_roadmap()

    def search_path_on_roadmap(self):
        """
        Search for a path on the graph.
        we use implict roadmap, so we don't build the whole roadmap ahead.

        :return: Path collection of motion planning
        :rtype: :class:`~discopygal.solvers_infra.PathCollection`
        """
        self.log("=== Starting Search ===")
        path_collection = PathCollection(metric=self.metric)

        self.log("Calling Graph.MRMH_A_star_search()...")
        d_path = self.graph.MRMH_A_star_search()

        if d_path is None:
            self.log("ERROR: No path found by search")
            return path_collection

        self.log(f"Path found! Length: {len(d_path)} points")

        for i, robot in enumerate(self.scene.robots):
            # Extract robot i's coordinates from each Point_d in the path
            # Each Point_d has format [robot0_x, robot0_y, robot1_x, robot1_y, ...]
            robot_path_points = []
            for point in d_path:
                # Extract this robot's coordinates (2D)
                robot_x = point[i * 2]
                robot_y = point[i * 2 + 1]
                # Create Point_2 for this robot at this path step
                robot_point_2d = Point_d(2, [robot_x, robot_y])
                robot_point_2 = conversions.Point_d_to_Point_2(robot_point_2d)
                robot_path_points.append(robot_point_2)

            robot_path = Path.path_from_points(robot_path_points, metric=self.metric)
            path_collection.add_robot_path(robot, robot_path)
            self.log(
                f"Robot {i} path: {len(robot_path_points)} points, length: {robot_path.calculate_length().to_double():.3f}"
            )

        self.log("=== Search Complete ===")
        return path_collection
