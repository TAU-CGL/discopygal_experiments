from discopygal.solvers.lattice_solver.latticebase import Latticebase
from math import sqrt
import numpy as np


class staggered_lattice(Latticebase):
    """
    Staggered Grid solver implementation that inherits from Latticebase.

    This solver uses a staggered grid lattice structure for multi-robot motion planning.
    The staggered grid provides better coverage properties compared to regular grids.

    :param eps: Epsilon parameter for lattice construction
    :type eps: :class:`float`
    :param delta: Delta parameter for lattice spacing
    :type delta: :class:`float`
    :param resolutions: List of resolution values for different lattice levels
    :type resolutions: :class:`list`
    :param heuristics: Dictionary of heuristic functions mapped to resolutions
    :type heuristics: :class:`dict`
    :param w1: Weight for heuristic function in key calculation (inflation factor)
    :type w1: :class:`float`
    :param w2: Weight for queue selection in multi-heuristic search
    :type w2: :class:`float`
    """

    def __init__(self, eps, delta, resolutions, heuristics, w1=1.0, w2=1.0, **kwargs):
        # Parse resolutions and heuristics if they come as strings
        if isinstance(resolutions, str):
            resolutions = eval(resolutions)
        if isinstance(heuristics, str):
            if heuristics.strip() == "euclidean":
                heuristics = {0: ("euclidean", 1.0)}
            else:
                heuristics = (
                    eval(heuristics) if heuristics.strip() else {0: ("euclidean", 1.0)}
                )

        super().__init__(eps, delta, resolutions, heuristics, w1, w2, **kwargs)
        self.grid = None

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            "eps": ("Epsilon:", 1.0, float),
            "delta": ("Delta:", 2.0, float),
            "resolutions": ("Resolutions:", "[1.0, 2.0, 2.5]", str),
            "heuristics": (
                "Heuristics:",
                '{0: ("euclidean", 1.0),1:("euclidean", 2.0), 2: ("individual_sum", 2.0), 3: ("euclidean", 2.5), 4: ("manhattan", 2.5)}',
                str,
            ),
            "w1": ("Weight 1:", 5.0, float),
            "w2": ("Weight 2:", 2.0, float),
        }
        args.update(super().get_arguments())
        return args

    def set_parameters(self):
        # Set staggered grid specific rescaling
        self.dim = len(self.scene.robots) * 2
        if self.dim % 2 == 0:
            self.rescale = sqrt(8.0 / self.dim)
        else:
            self.rescale = 4.0 / sqrt(2.0 * self.dim - 1)

        # Call base class to handle common setup
        super().set_parameters()

    def create_resolution_generator_matrices(self):
        """Generate matrices for all resolutions"""
        self.log("--- Generating Resolution Matrices ---")

        for resolution in self.resolutions:
            self.log(f"  Processing matrix for resolution {resolution}")
            res_data = self.resolution_data[resolution]
            rescale = res_data.res_rescale
            self.log(f"    Rescale factor: {rescale:.6f}")

            generator_matrix = np.zeros((self.dim, self.dim))

            for j in range(self.dim):
                for w in range(self.dim):
                    if j < self.dim - 1:
                        if j == w:
                            generator_matrix[j, w] = rescale
                        else:
                            generator_matrix[j, w] = 0
                    else:
                        generator_matrix[j, w] = rescale * 0.5

            # Transpose the matrix
            generator_matrix = generator_matrix.T

            # Store the matrix in the resolution data
            res_data.res_generator_matrix = generator_matrix
            res_data.res_inverse_generator_matrix = np.linalg.inv(generator_matrix)

            self.log(f"    Matrix shape: {generator_matrix.shape}")
            self.log(f"    Matrix determinant: {np.linalg.det(generator_matrix):.6f}")
            self.log(f"    Generator Matrix for resolution {resolution}:")
            self.log(f"{generator_matrix}")

        self.log("--- Matrix Generation Complete ---")
