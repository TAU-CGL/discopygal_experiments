from ...solvers_infra.SamplingSolver import SamplingSolver


class PRM(SamplingSolver):
    """
    The basic implementation of a Probabilistic Road Map (PRM) solver.
    Supports multi-robot motion planning, though might be inefficient for more than
    two-three robots.

    :param num_landmarks: number of landmarks to sample
    :type num_landmarks: :class:`int`
    :param k_nn: number of nearest neighbors to connect (k nearest neighbors)
    :type k_nn: :class:`int`
    :param nearest_neighbors: a nearest neighbors algorithm. if None then use sklearn implementation
    :type nearest_neighbors: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param metric: a metric for weighing edges, can be different then the nearest_neighbors metric!
        If None then use euclidean metric
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param sampler: sampling algorithm/method. if None then use uniform sampling
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    """
    def __init__(self, num_landmarks, k_nn, **kwargs):
        super().__init__(**kwargs)
        self.num_landmarks = num_landmarks
        self.k_nn = k_nn

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            'num_landmarks': ('Number of Landmarks:', 1000, int),
            'k_nn': ('K for nearest neighbors:', 15, int),
        }
        args.update(super().get_arguments())
        return args

    def build_roadmap(self):
        """
        Build a probabilistic roadmap for the robot in a given scene (sample random points and connect neighbors)

        :return: roadmap for the given scene
        :type: :class:`Roadmap`
        """
        roadmap = self.init_roadmap()
        roadmap.nearest_neighbors.max_cache = self.num_landmarks  # Fit points in nn only after adding all of them

        # Add start and end locations
        roadmap.add_point(self.start)
        roadmap.add_point(self.end)

        # Add valid points
        for i in range(self.num_landmarks):
            roadmap.add_sampled_point()
            if i % 100 == 0:
                self.log(f'added {i} landmarks in PRM roadmap')

        # Connect all points to their k nearest neighbors
        for cnt, point in enumerate(roadmap.points):
            neighbors = roadmap.nearest_neighbors.k_nearest(point, self.k_nn+1)
            for neighbor in neighbors:
                roadmap.add_edge(point, neighbor)

            if cnt % 100 == 0 and self.verbose:
                self.log(f'connected {cnt} landmarks to their nearest neighbors')

        return roadmap
