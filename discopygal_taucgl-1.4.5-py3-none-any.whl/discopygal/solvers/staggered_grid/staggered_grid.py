import heapq
import gc
from dataclasses import dataclass

from discopygal.bindings import Ker
from discopygal.solvers_infra import Scene, PathCollection, Path, PathPoint
from discopygal.geometry_utils import conversions

from .staggered_grid_base import StaggeredGridBase

@dataclass
class G_SCORE:
    costs: list

class PrmNode:
    def __init__(self, pt, name=""):
        self.point = pt
        self.name = name
        self.out_connections = {}
        self.in_connections = {}


class PrmEdge:
    def __init__(self, src, dest, eid, metric):
        self.src = src
        self.dest = dest
        self.name = "e"+str(eid)
        self.segment = conversions.create_segment_2(src.point, dest.point)
        self.cost = metric.dist(src.point, dest.point).to_double()


class PrmGraph:
    def __init__(self, milestones, writer, metric):
        self.edge_id = 0
        self.points_to_nodes = {}
        self.edges = []
        self.metric = metric
        self.goal = None
        for milestone in milestones:
            if milestone in self.points_to_nodes:
                print("Error, re entry of:", milestone.point, "in", milestone, file=writer)
            self.points_to_nodes[milestone.point] = milestone

    def insert_edge(self, milestone_point, neighbor_point):
        milestone = self.points_to_nodes[milestone_point]
        neighbor_node = self.points_to_nodes[neighbor_point]
        if neighbor_node == milestone:
            return
        if neighbor_node in milestone.out_connections or neighbor_node in milestone.in_connections:
            return
        self.edges.append(PrmEdge(milestone, neighbor_node, self.edge_id, self.metric))
        milestone.out_connections[neighbor_node] = self.edges[-1]
        neighbor_node.in_connections[milestone] = self.edges[-1]
        self.edge_id += 1

    @staticmethod
    def h(prm_graph, p, g_score):
        res = 0
        for p1, p2 in zip(p, prm_graph.goal):
            res += prm_graph.metric.dist(p1.point, p2.point).to_double()
        return res

    @staticmethod
    def get_g_score(g_score):
        return sum(g_score.costs)

    def a_star(self, robot_radius, start_points, goal_points, writer, metric):
        self.goal = tuple([self.points_to_nodes[p] for p in goal_points])

        def get_neighbors(points):
            connections_list = [list(p.out_connections.keys())+list(p.in_connections.keys()) for p in points]
            res = []
            for i, _ in enumerate(points):
                is_good = True
                for next_point in connections_list[i]:
                    for j, _ in enumerate(points):
                        if i == j:
                            continue
                        if metric.dist(next_point.point, points[j].point) < Ker.FT(2)*robot_radius:
                            is_good = False
                            break
                    if not is_good:
                        continue
                    seg = points[i].in_connections[next_point] if next_point in points[i].in_connections else points[i].out_connections[next_point]
                    for j, _ in enumerate(points):
                        if i == j:
                            continue
                        if Ker.squared_distance(seg.segment, conversions.Point_d_to_Point_2(points[j].point)) < Ker.FT(4)*robot_radius*robot_radius:
                            is_good = False
                            break
                    if not is_good:
                        continue
                    res.append((tuple([points[k] if k!=i else next_point for k in range(len(points))]), seg, i))
            return res

        temp_i = 0
        start = tuple([self.points_to_nodes[p] for p in start_points])

        def get_path(cf):
            return get_path_to_node(cf, self.goal)

        def get_path_to_node(cf, node):
            c = node
            path = [[p.point for p in c]]
            while c != start:
                c = cf[c]
                path.append([p.point for p in c])
            path.reverse()
            return path

        g_score = {start: G_SCORE([0] * len(start))}
        q = [(self.h(self, start, g_score), temp_i, start)]
        heapq.heapify(q)
        came_from = {}
        # temp_j = 0
        while len(q) > 0:
            curr_f_score, _, curr = heapq.heappop(q)
            if curr_f_score > (self.get_g_score(g_score[curr])+self.h(self, curr, g_score)):
                # temp_j += 1
                # if temp_j % 100000 == 0:
                #     print("temp_j", temp_j, file=writer)
                #     print(len(q), " ", len(came_from), file=writer)
                continue
            if curr == self.goal:
                return self.get_g_score(g_score[curr]), get_path(came_from)
            for neighbor, edge, robot_edge_index in get_neighbors(curr):
                tentative_g_score = G_SCORE(([*g_score[curr].costs]))
                tentative_g_score.costs[robot_edge_index] += edge.cost
                if neighbor not in g_score or self.get_g_score(tentative_g_score) < self.get_g_score(g_score[neighbor]):
                    came_from[neighbor] = curr
                    g_score[neighbor] = tentative_g_score
                    temp_i += 1
                    if temp_i % 100000 == 0:
                        print("Added", temp_i, "items to A_star heap", file=writer)
                        if temp_i % 1000000 == 0:
                            # TODO remove duplications?
                            gc.collect()
                    heapq.heappush(q, (self.get_g_score(tentative_g_score) + self.h(self, neighbor, g_score), temp_i, neighbor))
        print("error no path found", file=writer)
        return None, []


class StaggeredGrid(StaggeredGridBase):
    """
    Staggered Grid Solver - Creates a staggered grid as the roadmap and searches on it.

    Search is by using A*
    """
    def __init__(self, **kwargs):
        self.sample_method = "staggered_grid"
        super().__init__(**kwargs)
        self.PrmGraph = None

    def get_graph(self):
        """
        Return a graph (if applicable).
        Can be overridded by solvers.

        :return: graph whose vertices are Point_2 or Point_d
        :rtype: :class:`networkx.Graph` or :class:`None`
        """
        return self.grid.graph

    def load_scene(self, scene: Scene):
        """
        Load a scene into the solver.
        Also build the roadmap.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solvers_infra.Scene`
        """
        super().load_scene(scene)

        # Create PrmGraph the same as the grid so later A* will be applied
        milestones = [PrmNode(p) for p in self.grid.points]
        self.PrmGraph = PrmGraph(milestones, self.writer, self.metric)
        for edge in self.grid.edges:
            self.PrmGraph.insert_edge(*edge)

    def search_path_on_roadmap(self):
        path_collection = PathCollection(metric=self.metric)
        a_star_res, d_path = self.PrmGraph.a_star(
                        self.radius,
                        self.sources,
                        self.destinations,
                        self.writer,
                        self.metric)

        self.log(f"A_star_res: {a_star_res}")
        if a_star_res is None:
            return path_collection

        for i, robot in enumerate(self.scene.robots):
            path_collection.add_robot_path(robot,
                                           Path.path_from_points([conversions.Point_d_to_Point_2(point[i]) for point in d_path],
                                                                 metric=self.metric))

        return path_collection


class StaggeredGridMinPath(StaggeredGrid):
    @staticmethod
    def h(prm_graph, p, g_score):
        return float(max(prm_graph.metric.dist(p1.point, p2.point) + g_score[p].costs[i] for i, (p1, p2) in enumerate(zip(p, prm_graph.goal))))

    @staticmethod
    def get_g_score(g_score):
        return max(g_score.costs)

    def search_path_on_roadmap(self):
        self.PrmGraph.h = self.h
        self.PrmGraph.get_g_score = self.get_g_score

        return super().search_path_on_roadmap()
