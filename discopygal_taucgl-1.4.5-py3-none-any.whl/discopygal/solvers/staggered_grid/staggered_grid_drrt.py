from discopygal.solvers.rrt.drrt import dRRT
from discopygal.solvers.rrt.drrt_star import dRRT_star
from discopygal.solvers.staggered_grid.staggered_grid_base import StaggeredGridBase


class dRRTStaggeredGrid(StaggeredGridBase, dRRT):
    """
    Staggered Grid Solver - Creates a staggered grid as the roadmap and searches on it.

    Search is by using dRRT
    """
    @classmethod
    def get_arguments(cls):
        d = super().get_arguments()
        d.pop('prm_num_landmarks')
        return d


dRRTStarStaggeredGrid = type("dRRTStarStaggeredGrid", (dRRTStaggeredGrid, dRRT_star), {})
