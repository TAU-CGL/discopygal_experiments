import networkx as nx

from discopygal.bindings import FT
from discopygal.solvers.rrt import RRT
from discopygal.solvers_infra.metrics import Metric_SumDist
from discopygal.solvers_infra.operations_counter import OperationsCounter


class RRT_star(RRT):
    def __init__(self, radius: FT, **kwargs):
        self.radius = radius
        kwargs["metric"] = Metric_SumDist
        super().__init__(**kwargs)

    @classmethod
    def get_arguments(cls):
        args = super().get_arguments()
        args.update({
            'radius': ('Rewiring radius size:', 2, FT),
        })
        return args

    def cost(self, point):
        if point == self.start:
            return 0
        else:
            parent = self.roadmap.points[point]["parent"]
            return self.metric.dist(parent, point) + self.cost(parent)

    def build_roadmap(self):
        self.roadmap = self.init_roadmap()
        self.roadmap.add_point(self.start, cost=0, parent=self.start)

        cnt = 0
        while cnt <= self.num_landmarks:
            p_rand = self.roadmap.sample_free_point()
            p_near = self.roadmap.nearest_neighbors.k_nearest(p_rand, 1)[0]
            p_new = self.steer(p_near, p_rand, self.eta)

            if not self.roadmap.is_edge_valid(p_near, p_new):
                continue

            cost = self.cost(p_near) + self.metric.dist(p_near, p_new)

            self.roadmap.add_point(p_new, cost=cost, parent=p_near)
            self.roadmap.add_edge(p_near, p_new)

            with OperationsCounter.count_call_context("ego_graph", self.roadmap.graph.number_of_nodes()):
                neighbors = nx.ego_graph(self.roadmap.graph, p_new, self.radius, distance="weight")

            for neighbor in neighbors.nodes:
                neighbor_distance = self.metric.dist(neighbor, p_new)
                neighbor_cost = self.cost(neighbor) + neighbor_distance
                if neighbor_cost < cost:
                    if not self.roadmap.is_edge_valid(neighbor, p_new):
                        continue
                    cost = neighbor_cost
                    self.roadmap.graph.remove_edge(p_near, p_new)
                    self.roadmap.add_edge(neighbor, p_new, check_if_valid=False)
                    self.roadmap.points[p_new]["parent"] = neighbor
                    p_near = neighbor

            for neighbor in neighbors.nodes:
                neighbor_distance = self.metric.dist(p_new, neighbor)
                new_cost = cost + neighbor_distance
                if new_cost < self.cost(neighbor):
                    if neighbor == self.roadmap.points[p_new]["parent"] or not self.roadmap.is_edge_valid(neighbor, p_new):
                        continue
                    self.roadmap.graph.remove_edge(self.roadmap.points[neighbor]["parent"], neighbor)
                    # self.roadmap.points[neighbor]["cost"] = new_cost
                    self.roadmap.points[neighbor]["parent"] = p_new
                    self.roadmap.add_edge(p_new, neighbor, check_if_valid=False)

            cnt += 1
            if cnt % 100 == 0:
                self.log(f'added {cnt} landmarks in RRT*')

        self.roadmap.add_point(self.end)
        for point in self.roadmap.points:
            if self.roadmap.is_edge_valid(point, self.end):
                self.roadmap.add_edge(point, self.end)

        return self.roadmap
