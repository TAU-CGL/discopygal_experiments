from ...bindings import FT, Point_d
from ...solvers_infra.Solver import Solver
from ...solvers_infra.SamplingSolver import SamplingSolver


class RRT(SamplingSolver):
    """
    Implementation of the plain RRT algorithm.
    Supports multi-robot motion planning, though might be inefficient for more than
    two-three robots.

    :param num_landmarks: number of landmarks to sample
    :type num_landmarks: :class:`int`
    :param eta: maximum distance when steering
    :type eta: :class:`~discopygal.bindings.FT`
    :param nearest_neighbors: a nearest neighbors algorithm. if None then use sklearn implementation
    :type nearest_neighbors: :class:`~discopygal.solvers_infra.nearest_neighbors.NearestNeighbors` or :class:`None`
    :param metric: a metric for weighing edges, can be different then the nearest_neighbors metric!
        If None then use euclidean metric
    :type metric: :class:`~discopygal.solvers_infra.metrics.Metric` or :class:`None`
    :param sampler: sampling algorithm/method. if None then use uniform sampling
    :type sampler: :class:`~discopygal.solvers_infra.samplers.Sampler`
    """
    def __init__(self, num_landmarks, eta, **kwargs):
        super().__init__(**kwargs)
        self.num_landmarks = num_landmarks
        self.eta = eta

    @classmethod
    def get_arguments(cls):
        """
        Return a list of arguments and their description, defaults and types.
        Can be used by a GUI to generate fields dynamically.
        Should be overridded by solvers.

        :return: arguments dict
        :rtype: :class:`dict`
        """
        args = {
            'num_landmarks': ('Number of Landmarks:', 2000, int),
            'eta': ('eta for steering:', 1, FT),
            'bounding_margin_width_factor': ('Margin width factor (for bounding box):', Solver.DEFAULT_BOUNDS_MARGIN_FACTOR, FT)
        }
        args.update(super().get_arguments())
        return args

    def steer(self, p_near, p_rand, eta):
        """
        Steer in eta units from p_near towards p_rand
        """
        dist = self.metric.dist(p_near, p_rand)
        alpha = eta / dist
        alpha = alpha.to_double()
        if alpha > 1:
            alpha = 1
        d = p_near.dimension()
        coords = []
        for i in range(d):
            coords.append(p_rand[i] * alpha + p_near[i] * (1 - alpha))
        return Point_d(d, coords)

    def build_roadmap(self):
        ################
        # Build the RRT
        ################
        roadmap = self.init_roadmap()

        # Add start & end points (but only the start to the graph)
        roadmap.add_point(self.start)

        cnt = 0
        while cnt < self.num_landmarks:
            p_rand = roadmap.sample_free_point()
            p_near = roadmap.nearest_neighbors.k_nearest(p_rand, 1)[0]
            p_new = self.steer(p_near, p_rand, self.eta)
            if roadmap.add_edge(p_near, p_new):
                cnt += 1

            if cnt % 100 == 0:
                self.log(f'added {cnt} landmarks in RRT')

        # Try adding the target point
        p_new = self.end
        p_near = roadmap.nearest_neighbors.k_nearest(p_new, 1)[0]
        roadmap.add_point(p_new)
        roadmap.add_edge(p_near, p_new)

        return roadmap
