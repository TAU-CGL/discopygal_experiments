from discopygal.solvers.rrt.drrt import dRRT
from discopygal.geometry_utils import conversions


class ao_dRRT(dRRT):
    def __init__(self, expansion_times, **kwargs):
        super().__init__(**kwargs)
        self.expansion_times = expansion_times

    @classmethod
    def get_arguments(cls):
        args = {'expansion_times': ('Number of Expansions:', 10, int)}
        args.update(super().get_arguments())
        return args

    def search_tensor_roadmap(self):
        """
        Load a scene into the solver.
        Also build the tensor roadmap.

        :param scene: scene to load
        :type scene: :class:`~discopygal.solver.Scene`
        """
        tensor_roadmap = self.tensor_roadmap
        end = tensor_roadmap.end

        for i in range(self.expansion_times):
            # Add the given amount of landmarks to the RRT
            # EXPAND(T)
            self.log(f"Expaned iteration {i}")
            cnt = 0
            while cnt <= self.num_landmarks:
                added = self.expand_ao_drrt()

                if added:
                    cnt += 1
                    if cnt % 100 == 0:
                        self.log(f'added {cnt} landmarks in dRRT')

            # Finally try to connect to the end point
            tensor_roadmap.T.add_point(end)
            neighbors = tensor_roadmap.T.nearest_neighbors.k_nearest(end, self.k_nn+1)
            for neighbor in neighbors:
                if neighbor != tensor_roadmap.end:
                    tensor_roadmap.try_connecting(neighbor, end)

    # ao-dRRT
    def expand_ao_drrt(self):
        # q_rand <-- RANDOM_SAMPLE()
        q_rand = []
        for _ in self.tensor_roadmap.robots:
            q_rand.append(self.sampler.sample())
        q_rand = conversions.Point_2_list_to_Point_d(q_rand)

        # q_near <-- NEAREST_NEIGHBOR(T, q_rand)
        q_near = self.tensor_roadmap.nearest_tensor_vertex(q_rand)

        # q_new <-- O_D(q_near, q_rand)
        # if q_new \not\in R then
        #       T.add_vertex(q_new)
        #       T.add_edge(q_near, q_new)
        # NOTE: in original paper there is no treatment for when the "oracle"
        #       doesn't return a valid edge, here we just ignore and try again
        return self.tensor_roadmap.find_best_edge(q_near, q_rand)


