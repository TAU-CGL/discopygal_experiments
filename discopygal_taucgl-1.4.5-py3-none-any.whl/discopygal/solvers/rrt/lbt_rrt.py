"""
Adapted from code by Shaked Klingbell
"""
import math
import heapq

from discopygal.bindings import FT
from discopygal.solvers.rrt.rrt import RRT
from discopygal.solvers_infra.metrics import Metric_Euclidean

class Glb_Graph():
    def __init__(self):
        self.V = {}

    def get_vertex(self, point):
        return self.V[point]

    def set_start(self, point):
        self.V[point] = Glb_Vertex(point, start=True)

    def insert_edge_sssp(self, parent_point, child_point):
        I = []
        if parent_point not in self.V:
            self.V[parent_point] = Glb_Vertex(parent_point)
        if child_point not in self.V:
            self.V[child_point] = Glb_Vertex(child_point)
        parent = self.V[parent_point]
        child = self.V[child_point]
        child.add_parent(parent, I)
        parent.add_child(child)
        return I

    def delete_edge_sssp(self, parent_point, child_point):
        D = {}
        if parent_point in self.V and child_point in self.V:
            parent = self.V[parent_point]
            child = self.V[child_point]
            child.remove_parent(parent, D)
            parent.remove_child(child)
        return D


class Glb_Vertex():
    def __init__(self, point, start=False):
        self.point = point
        self.sssp_parent = None
        self.possible_parents_costs = {}
        self.children_and_dists = {}
        self.cost = 0 if start else float('inf')

    def get_point(self):
        return self.point

    def get_cost(self):
        return self.cost

    def get_sssp_parent(self):
        return self.sssp_parent

    def update_parent_cost(self, parent):
        if parent in self.possible_parents_costs:
            dist = Metric_Euclidean.dist(self.point, parent.get_point()).to_double()
            self.possible_parents_costs[parent] = parent.get_cost() + dist

    def add_parent(self, parent, I):
        dist = Metric_Euclidean.dist(self.point, parent.get_point()).to_double()
        new_cost = parent.get_cost() + dist
        self.possible_parents_costs[parent] = new_cost
        self.propagate_costs_on_insert(new_cost, parent, I)

    def remove_parent(self, parent, D):
        if parent in self.possible_parents_costs:
            del self.possible_parents_costs[parent]
        self.propagate_costs_on_removal(parent, D)

    def propagate_costs_on_insert(self, new_cost, parent, I):
        if (self.cost is None) or (new_cost < self.cost):
            I.append((self, new_cost))
            self.cost = new_cost
            self.sssp_parent = parent
            # In Dijkstra, we update children costs from the smallest distance to the largest
            for child, dist in sorted(self.children_and_dists.items(), key=lambda x: x[1]):
                child_cost = self.cost + dist
                child.propagate_costs_on_insert(child_cost, self, I)

    def propagate_costs_on_removal(self, removed_parent, D):
        # if our cost is affected by the removal
        if self.sssp_parent == removed_parent:
            new_parent, new_cost = min(self.possible_parents_costs.items(), key=lambda x: x[1])
            D[self] = new_cost
            self.cost = new_cost
            self.sssp_parent = new_parent
            # In Dijkstra, we update children costs from the smallest distance to the largest
            for child, dist in sorted(self.children_and_dists.items(), key=lambda x: x[1]):
                child.update_parent_cost(self)
                child.propagate_costs_on_removal(self, D)

    def add_child(self, child):
        self.children_and_dists[child] = Metric_Euclidean.dist(self.point, child.get_point()).to_double()

    def remove_child(self, child):
        del self.children_and_dists[child]

    def dist(self):
        pass

    def __lt__(self, other):
        return self.cost < other.cost


class LBT_RRT(RRT):
    """
    """

    def __init__(self, epsilon, **kwargs):
        super().__init__(**kwargs)
        self.epsilon = epsilon
        self.last_length = None
        self.Tapx = None
        self.Glb = None

    @classmethod
    def get_arguments(cls):
        arguments = super().get_arguments()
        arguments.update({'epsilon': ('epsilon for bound:', 3, FT)})
        return arguments

    def connect_new_node_to_tapx(self, new_node, parent_node):
        self.Tapx.add_edge(parent_node, new_node)
        if parent_node in self.Tapx.points:
            self.Tapx.points[new_node]['cost'] = self.Tapx.points[parent_node]['cost'] + self.Tapx.edges[parent_node, new_node]['weight']

    def build_roadmap(self):
        ########################################
        # Build the LBT-RRT roadmap
        # Following algorithm 5 from the paper
        ########################################
        self.Tapx = self.init_roadmap(is_directed=True)
        self.Glb = Glb_Graph()

        self.Tapx.add_point(self.start, cost=FT(0))  # line [1] in the paper
        self.Glb.set_start(self.start)

        cnt = 0
        while cnt < self.num_landmarks: # line [2]
            p_rand = self.Tapx.sample_free_point()  # line [3]
            p_near = self.Tapx.nearest_neighbors.k_nearest(p_rand, 1)[0]  # line [4]
            p_new = self.steer(p_near, p_rand, self.eta)  # line [5]

            if self.Tapx.is_edge_valid(p_near, p_new):  # line [6]
                cnt += 1
                self.connect_new_node_to_tapx(p_new, p_near)  # line [8-9]
                self.Glb.insert_edge_sssp(p_near, p_new)  # line [10-11]
                k = int(2 * math.e * math.log(len(self.Tapx.points)))
                X_near = self.Tapx.nearest_neighbors.k_nearest(p_new, k)  # line [12]
                for x_near in X_near:  # line [13]
                    self.consider_edge(x_near, p_new)  # line [14]
                for x_near in X_near:  # line [15]
                    self.consider_edge(p_new, x_near)  # line [16]

                if cnt % 100 == 0 and self.verbose:
                    self.log(f'added {cnt} landmarks in LBT-RRT')

        # Try adding the target point
        p_new = self.end
        self.Tapx.add_point(p_new)
        k = int(2 * math.e * math.log(len(self.Tapx.points)))
        X_near = self.Tapx.nearest_neighbors.k_nearest(p_new, k)
        for x_near in sorted(X_near, key=lambda x: self.metric.dist(x, p_new)):
            if self.Tapx.is_edge_valid(x_near, p_new):
                self.connect_new_node_to_tapx(p_new, x_near)

        return self.Tapx

    def consider_edge(self, x1, x2):
        """
        Following algorithm 6 from the paper.
        """
        if x1 == x2: return
        I = self.Glb.insert_edge_sssp(x1, x2)  # line [1]
        Q = sorted(I, key=lambda item: item[1])
        heapq.heapify(Q)  # line [2]
        while len(Q) > 0:  # line [3]
            x, x_Glb_cost = Q[0]  # line [4]
            if self.Tapx.points[x.get_point()]['cost'] > (FT(1) + self.epsilon)*x_Glb_cost:  # line [5]
                x_parent = x.get_sssp_parent().get_point()  # line [6]
                x = x.get_point()
                if self.Tapx.is_edge_valid(x_parent, x):  # line [7]
                    current_parent = list(self.Tapx.graph.predecessors(x))[0]
                    self.Tapx.graph.remove_edge(current_parent, x)
                    self.connect_new_node_to_tapx(x, x_parent)   # line [8]
                    heapq.heappop(Q)  # line [9]
                else:  # line [10]
                    D = self.Glb.delete_edge_sssp(x_parent, x)  # line [11]
                    Q = sorted([(vertex, D.get(vertex, cost)) for vertex, cost in Q], key=lambda item: item[1])  # line [12-13]
                    heapq.heapify(Q)
            else:  # line [14]
                heapq.heappop(Q)  # line [15]
