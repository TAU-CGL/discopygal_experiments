from discopygal.solvers_infra.Solver import Solver
from discopygal.solvers_infra import PathCollection, Path, PathPoint
from discopygal.bindings import Point_2, Polygon_2

import RA
from RA import Swapping_area, Shortest_path, Modify_path


def CGALPY_Point_2_to_RA_Point_2(point: Point_2) -> RA.Ker.Point_2:
    return RA.Ker.Point_2(point.x().to_double(), point.y().to_double())

def RA_Point_2_to_CGALPY_Point_2(point: RA.Ker.Point_2) -> Point_2:
    return Point_2(point.x().to_double(), point.y().to_double())

def CGALPY_Polygon_2_to_RA_Polygon_2(poly: Polygon_2) -> RA.Pol.Polygon_2:
    vertices = [CGALPY_Point_2_to_RA_Point_2(v) for v in poly.vertices()]
    return RA.Pol.Polygon_2(vertices)


class RevolvingAreas(Solver):
    def original_solve_function(self, startPositions, targetPositions, obstacles, optimizeOrderOfPaths, path_collection):
        numOfRobots = len(self.scene.robots)
        swappingAreasOfStarts = []
        swappingAreasOfTargets = []

        Swapping_area.init(obstacles)

        for i in range(numOfRobots):
            swappingAreasOfStarts.append(Swapping_area(i, True, startPositions, targetPositions, False))
            swappingAreasOfTargets.append(Swapping_area(i, False, startPositions, targetPositions, False))
            self.log(f"found swapping areas for robot {i}")

        Shortest_path.Init(obstacles)
        originalPaths = [None for _ in range(numOfRobots)]
        for i in range(numOfRobots):
            self.log(f"start finding path for robot {i}")
            path = Shortest_path(i, startPositions[i], targetPositions[i])
            originalPaths[i] = path

        if optimizeOrderOfPaths:
            self.log("finding order of paths")
            orderOfPaths = RA.OrderOfPaths(originalPaths, swappingAreasOfStarts, swappingAreasOfTargets).GetOrder()
            newSwapping_areasOfStarts = []
            newSwapping_areasOfTargets = []
            newOriginalPaths = []

            for i in range(numOfRobots):
                newSwapping_areasOfStarts.append(swappingAreasOfStarts[orderOfPaths[i]])
                newSwapping_areasOfTargets.append(swappingAreasOfTargets[orderOfPaths[i]])
                newOriginalPaths.append(originalPaths[orderOfPaths[i]])

                newSwapping_areasOfStarts[i].robotIndex = i
                newSwapping_areasOfTargets[i].robotIndex = i
                newOriginalPaths[i].robotIndex = i

            swappingAreasOfStarts = newSwapping_areasOfStarts
            swappingAreasOfTargets = newSwapping_areasOfTargets
            originalPaths = newOriginalPaths


        for i in range(numOfRobots):
            self.log(f"start modifying path for robot {i}")
            newPath = Modify_path(path, swappingAreasOfStarts, swappingAreasOfTargets).NewPath()
            current_path_points = []
            for arc in newPath.arcs:
                current_path_points.extend([RA_Point_2_to_CGALPY_Point_2(p) for p in arc.PointsOnArc()])
            path_collection.add_robot_path(self.scene.robots[i], Path.path_from_points(current_path_points))

    def binded_solve_function(self, startPositions, targetPositions, obstacles, optimizeOrderOfPaths, path_collection):
        RA.solve(startPositions, targetPositions, obstacles, "temp_sol", optimizeOrderOfPaths, True)
        paths = [Path([PathPoint(robot.start)]) for robot in self.scene.robots]

        with open("temp_sol.txt", "r") as f:
            lines_iter = iter(f.readlines())
            for line in lines_iter:
                if "frame_of_moving" not in line:
                    continue
                line = next(lines_iter)
                robot_indices = []
                while not line.isspace() and line != "":
                    robot_index, x, y = [float(num) for num in line.split()]
                    paths[int(robot_index)].points.append(PathPoint(Point_2(x, y)))
                    robot_indices.append(robot_index)
                    line = next(lines_iter)
                for i, _ in enumerate(self.scene.robots):
                    if i not in robot_indices:
                        paths[i].points.append(paths[i].points[-1])

        for i, robot in enumerate(self.scene.robots):
            path_collection.add_robot_path(robot, paths[i])

    def _solve(self):
        path_collection = PathCollection()

        obstacles = [CGALPY_Polygon_2_to_RA_Polygon_2(obstacle.poly) for obstacle in self.scene.obstacles]
        startPositions = [CGALPY_Point_2_to_RA_Point_2(robot.start) for robot in self.scene.robots]
        targetPositions = [CGALPY_Point_2_to_RA_Point_2(robot.end) for robot in self.scene.robots]

        # solve_function = self.original_solve_function
        solve_function = self.binded_solve_function

        solve_function(startPositions, targetPositions, obstacles, False, path_collection)

        self.log(f"Done!")
        return path_collection

    @classmethod
    def get_arguments(cls):
        return {}
