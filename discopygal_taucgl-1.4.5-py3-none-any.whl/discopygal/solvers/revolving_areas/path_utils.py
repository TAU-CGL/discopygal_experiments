from typing import List, Optional
from functools import cache
import random
import bisect
from heapq import merge
from itertools import product
from tqdm import tqdm

from discopygal.bindings import Point_2, Point_d, FT, Polygon_2, Segment_2
from discopygal.geometry_utils import conversions

from .metric_utils import makespan_d
from .geometry_utils import intersect_segment_inflated_segment

EPSILON = 1e-10


class PathsCSpace:
    def __init__(self, paths: List[List[Point_d]]):
        self.paths = paths
        self.paths_legnths = []
        self.paths_cumsum_lengths = []
        for path in self.paths:
            path_lengths = []
            path_cumsum_lengths = [0]
            for src, dst in zip(path, path[1:]):
                path_lengths.append(makespan_d(src, dst))
                path_cumsum_lengths.append(path_cumsum_lengths[-1] + path_lengths[-1])

            self.paths_legnths.append(path_lengths)
            self.paths_cumsum_lengths.append(path_cumsum_lengths)

    def get_start_cspace_point(self, path_idx: int) -> float:
        return 0

    def get_end_cspace_point(self, path_idx: int) -> float:
        return self.paths_cumsum_lengths[path_idx][-1]

    def get_combined_start_cspace_point(self) -> Point_d:
        start_points = [
            self.get_start_cspace_point(path_idx=i) for i in range(len(self.paths))
        ]
        return Point_d(len(start_points), start_points)

    def get_combined_end_cspace_point(self) -> Point_d:
        end_points = [
            self.get_end_cspace_point(path_idx=i) for i in range(len(self.paths))
        ]
        return Point_d(len(end_points), end_points)

    def sample_cspace_point(self, path_idx: int) -> float:
        return random.uniform(
            self.get_start_cspace_point(path_idx=path_idx),
            self.get_end_cspace_point(path_idx=path_idx),
        )

    def sample_combined_cspace_point(self) -> List[float]:
        cspace_points = [
            self.sample_cspace_point(path_idx=i) for i in range(len(self.paths))
        ]
        return Point_d(len(cspace_points), cspace_points)

    def get_cspace_obstacle(
        self,
        segment1_relative_pos: float,
        segment1_makespan: float,
        segment1: Segment_2,
        segment2_relative_pos: float,
        segment2_makespan: float,
        segment2: Segment_2,
        distance: float,
    ) -> Optional[Polygon_2]:
        segment1_relative_inter1, segment1_relative_inter2 = (
            intersect_segment_inflated_segment(
                segment=segment1, inflated_segment=segment2, inflate_value=distance
            )
        )
        segment2_relative_inter1, segment2_relative_inter2 = (
            intersect_segment_inflated_segment(
                segment=segment2, inflated_segment=segment1, inflate_value=distance
            )
        )

        inters = (
            segment1_relative_inter1,
            segment1_relative_inter2,
            segment2_relative_inter1,
            segment2_relative_inter2,
        )
        if all([inter == None for inter in inters]):
            return None

        # Sanity check.
        assert (
            None not in inters
        ), f"{segment1 = }, {segment2 = }, {distance = }, {inters = }"

        segment1_inter1 = (
            segment1_relative_pos + segment1_relative_inter1 * segment1_makespan
        )
        segment1_inter2 = (
            segment1_relative_pos + segment1_relative_inter2 * segment1_makespan
        )

        segment2_inter1 = (
            segment2_relative_pos + segment2_relative_inter1 * segment2_makespan
        )
        segment2_inter2 = (
            segment2_relative_pos + segment2_relative_inter2 * segment2_makespan
        )

        return Polygon_2(
            [
                Point_2(segment1_inter1, segment2_inter1),
                Point_2(segment1_inter1, segment2_inter2),
                Point_2(segment1_inter2, segment2_inter2),
                Point_2(segment1_inter2, segment2_inter1),
            ]
        )

    def segment_list_from_segment_d(self, src: Point_d, dst: Point_d):
        src_list = conversions.Point_d_to_Point_2_list(src)
        dst_list = conversions.Point_d_to_Point_2_list(dst)

        return [Segment_2(s, d) for s, d in zip(src_list, dst_list)]

    def get_cspace_obstacles(
        self, radiuses1: List[float], radiuses2: List[float]
    ) -> List[Polygon_2]:
        assert len(self.paths) == 2, "Functions is supported for 2 paths only."
        MIN_REPORT_PROGRESS = 1 << 15

        path1 = self.paths[0]
        path1_cumsum_lengths = self.paths_cumsum_lengths[0]

        path2 = self.paths[1]
        path2_cumsum_lengths = self.paths_cumsum_lengths[1]

        radiuses_product = list(product(radiuses1, radiuses2))
        cspace_obstacles = []
        max_obstacles = (len(path1) - 1) * (len(path2) - 1) * len(radiuses_product)
        progress = tqdm(
            total=max_obstacles,
            desc="Computing cspace obstacles",
            disable=max_obstacles < MIN_REPORT_PROGRESS,
        )
        for idx1, (src1, dst1) in enumerate(zip(path1, path1[1:])):
            segment1_list = self.segment_list_from_segment_d(src1, dst1)
            segment1_makespan = makespan_d(src1, dst1)
            for idx2, (src2, dst2) in enumerate(zip(path2, path2[1:])):
                segment2_list = self.segment_list_from_segment_d(src2, dst2)
                segment2_makespan = makespan_d(src2, dst2)
                for (segment1, segment2), (radius1, radius2) in zip(
                    product(segment1_list, segment2_list), radiuses_product
                ):
                    progress.update()
                    cspace_obstacle = self.get_cspace_obstacle(
                        segment1_relative_pos=path1_cumsum_lengths[idx1],
                        segment1_makespan=segment1_makespan,
                        segment1=segment1,
                        segment2_relative_pos=path2_cumsum_lengths[idx2],
                        segment2_makespan=segment2_makespan,
                        segment2=segment2,
                        distance=radius1 + radius2 + EPSILON,
                    )
                    if cspace_obstacle:
                        cspace_obstacles.append(cspace_obstacle)
        progress.close()

        return cspace_obstacles

    @cache
    def edge_index_of_cspace_point(self, path_idx: int, cspace_point: float) -> int:
        path_cumsum_lengths = self.paths_cumsum_lengths[path_idx]
        path_len = path_cumsum_lengths[-1]

        if cspace_point == 0:
            return 0

        bisect_index = bisect.bisect_left(path_cumsum_lengths, cspace_point)

        return bisect_index - 1

    def get_relative_point_on_edge(self, path_idx: int, edge_idx: int, t: float):
        path = self.paths[path_idx]

        edge_start = path[edge_idx]
        edge_end = path[edge_idx + 1]

        edge_start_list = conversions.Point_d_to_Point_2_list(edge_start)
        edge_end_list = conversions.Point_d_to_Point_2_list(edge_end)

        relative_point = []
        for pos_start, pos_end in zip(edge_start_list, edge_end_list):
            x = FT(1 - t) * pos_start.x() + FT(t) * pos_end.x()
            y = FT(1 - t) * pos_start.y() + FT(t) * pos_end.y()
            relative_point.append(Point_2(x, y))

        return conversions.Point_2_list_to_Point_d(relative_point)

    @cache
    def cspace_point_to_point(self, path_idx: int, cspace_point: float) -> Point_d:
        path_cumsum_lengths = self.paths_cumsum_lengths[path_idx]

        edge_idx = self.edge_index_of_cspace_point(
            path_idx=path_idx, cspace_point=cspace_point
        )

        edge_point = cspace_point - path_cumsum_lengths[edge_idx]
        edge_len = self.paths_legnths[path_idx][edge_idx]
        t = edge_point
        if abs(edge_len) > EPSILON:
            t /= edge_len
        assert (
            0 - EPSILON <= t <= 1 + EPSILON
        ), f"{t = }, {path_idx = }, {edge_idx = }, {edge_len = }, {cspace_point = }"  # Sanity check.

        return self.get_relative_point_on_edge(
            path_idx=path_idx, edge_idx=edge_idx, t=t
        )

    @cache
    def combined_cspace_point_to_combined_point(
        self, combined_cspace_point: Point_d
    ) -> List[Point_d]:
        combined_point = [
            self.cspace_point_to_point(path_idx=i, cspace_point=cspace_point)
            for i, cspace_point in enumerate(combined_cspace_point.cartesians())
        ]
        return combined_point

    @cache
    def cspace_edge_to_path(
        self, path_idx: int, src: float, dst: float
    ) -> List[Point_d]:
        if dst < src:
            return self.cspace_edge_to_path(path_idx=path_idx, src=dst, dst=src)[::-1]

        src_edge_start = self.edge_index_of_cspace_point(path_idx, src)
        src_edge_end = src_edge_start + 1
        dst_edge_start = self.edge_index_of_cspace_point(path_idx, dst)

        start_point = self.cspace_point_to_point(path_idx=path_idx, cspace_point=src)
        end_point = self.cspace_point_to_point(path_idx=path_idx, cspace_point=dst)

        sub_path = [start_point]
        path = self.paths[path_idx]
        for point_idx in range(src_edge_end, dst_edge_start + 1):
            sub_path.append(path[point_idx])

        sub_path.append(end_point)
        return sub_path

    @cache
    def combined_cspace_edge_to_combined_path(
        self, src: Point_d, dst: Point_d
    ) -> List[List[Point_d]]:
        assert (
            src.dimension() == dst.dimension()
        ), "src point and dst point are not of the same dimensions."
        src_cspace_points = src.cartesians()
        dst_cspace_points = dst.cartesians()

        combined_path = []
        for path_idx, (src_point, dst_point) in enumerate(
            zip(src_cspace_points, dst_cspace_points)
        ):
            combined_path.append(
                self.cspace_edge_to_path(
                    path_idx=path_idx, src=src_point, dst=dst_point
                )
            )

        return combined_path

    @cache
    def cspace_edge_to_cspace_path(self, path_idx: int, src: float, dst: float):
        """Exactly as `cspace_edge_to_path` but returns the cspace points of the path."""
        if dst < src:
            return self.cspace_edge_to_cspace_path(path_idx=path_idx, src=dst, dst=src)[
                ::-1
            ]

        src_edge_start = self.edge_index_of_cspace_point(path_idx, src)
        src_edge_end = src_edge_start + 1
        dst_edge_start = self.edge_index_of_cspace_point(path_idx, dst)

        sub_path = [src]
        path_cumsum_lengths = self.paths_cumsum_lengths[path_idx]
        for point_idx in range(src_edge_end, dst_edge_start + 1):
            sub_path.append(path_cumsum_lengths[point_idx])

        sub_path.append(dst)
        return sub_path

    @staticmethod
    def cspace_point_to_normalized_point(cspace_point: float, src: float, dst: float):
        if src < dst:
            assert (
                src <= cspace_point <= dst
            ), f"Invalid cspace point: {src = }, {dst = }, {cspace_point = }"
            return cspace_point - src
        else:
            assert (
                dst <= cspace_point <= src
            ), f"Invalid cspace point: {src = }, {dst = }, {cspace_point = }"
            return -(cspace_point - src)

    @staticmethod
    def normalized_point_to_cspace_point(
        normalized_point: float, src: float, dst: float
    ):
        if src < dst:
            return min(normalized_point + src, dst)
        else:
            return max(-normalized_point + src, dst)

    def synchronized_combined_cspace_edge_to_combined_path(
        self, src: Point_d, dst: Point_d
    ) -> List[List[Point_d]]:
        """Function makes sure all the edges are transformed into equal lengths paths that minimize makespan."""

        assert (
            src.dimension() == dst.dimension()
        ), "src point and dst point are not of the same dimensions."
        dim = src.dimension()
        src_cspace_points = src.cartesians()
        dst_cspace_points = dst.cartesians()

        normalized_cspace_paths = []
        for path_idx, (src_point, dst_point) in enumerate(
            zip(src_cspace_points, dst_cspace_points)
        ):
            cspace_path = self.cspace_edge_to_cspace_path(
                path_idx=path_idx, src=src_point, dst=dst_point
            )
            normalized_cspace_paths.append(
                [
                    PathsCSpace.cspace_point_to_normalized_point(
                        cspace_point=cspace_point, src=src_point, dst=dst_point
                    )
                    for cspace_point in cspace_path
                ]
            )

        synchronized_normalized_cspace_path = list(merge(*normalized_cspace_paths))

        combined_path = []
        for path_idx, (src_point, dst_point) in enumerate(
            zip(src_cspace_points, dst_cspace_points)
        ):
            combined_path.append(
                [
                    self.cspace_point_to_point(
                        path_idx=path_idx,
                        cspace_point=PathsCSpace.normalized_point_to_cspace_point(
                            normalized_point=normalized_cspace_point,
                            src=src_point,
                            dst=dst_point,
                        ),
                    )
                    for normalized_cspace_point in synchronized_normalized_cspace_path
                ]
            )

        return combined_path

    def cspace_path_to_path(
        self, path_idx: int, cspace_path: List[float]
    ) -> List[Point_d]:
        if len(cspace_path) == 0:
            return []

        path = [
            self.cspace_point_to_point(path_idx=path_idx, cspace_point=cspace_path[0])
        ]
        for src, dst in zip(cspace_path, cspace_path[1:]):
            edge_path = self.cspace_edge_to_path(path_idx=path_idx, src=src, dst=dst)
            path.extend(edge_path[1:])

        return path

    def combined_cspace_path_to_combined_path(
        self, combined_cspace_path: List[Point_d]
    ) -> List[List[Point_d]]:
        if len(combined_cspace_path) == 0:
            return []

        combined_path = [
            [point]
            for point in self.combined_cspace_point_to_combined_point(
                combined_cspace_point=combined_cspace_path[0]
            )
        ]
        for cspace_src, cspace_dst in zip(
            combined_cspace_path, combined_cspace_path[1:]
        ):
            combined_edge_path = (
                self.synchronized_combined_cspace_edge_to_combined_path(
                    src=cspace_src, dst=cspace_dst
                )
            )
            for i, path in enumerate(combined_edge_path):
                combined_path[i].extend(path[1:])

        return combined_path


def combined_point_to_combined_point_list(combined_point: List[Point_d]):
    combined_point_list = []
    for point_d in combined_point:
        combined_point_list.extend(conversions.Point_d_to_Point_2_list(point_d))

    return combined_point_list


def combined_point_to_tensor_point(combined_point: List[Point_d]):
    combined_point_list = combined_point_to_combined_point_list(combined_point)
    return conversions.Point_2_list_to_Point_d(combined_point_list)


def combined_path_to_tensor_path(combined_path: List[List[Point_d]]):

    combined_path_len = len(combined_path[0])
    tensor_path = []

    # Transpose paths and create tensor path.
    for i in range(combined_path_len):
        combined_point = []
        for path_idx in range(len(combined_path)):
            combined_point.append(combined_path[path_idx][i])

        tensor_point = combined_point_to_tensor_point(combined_point)
        tensor_path.append(tensor_point)

    return tensor_path
