"""
All code here is adapted from code by Netanel Esman
"""
from .revolving_areas_solver import RevolvingAreas
