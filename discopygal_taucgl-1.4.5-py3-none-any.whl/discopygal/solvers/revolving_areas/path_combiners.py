from typing import List, Optional, Tuple
import networkx as nx
from itertools import product, combinations_with_replacement
from tqdm import tqdm
import random

from discopygal.geometry_utils import conversions, collision_detection
from discopygal.solvers_infra import load_object_from_dict, RobotDisc
from discopygal.bindings import Point_2, Point_d, Segment_2, Polygon_2
from discopygal.solvers_infra.nearest_neighbors import NearestNeighbors_sklearn

from .metric_utils import Metric_Linf, path_makespan_d, l2_dist
from .path_utils import (
    PathsCSpace,
    combined_path_to_tensor_path,
    combined_point_to_combined_point_list,
)
from .path_combiner_mode import PathCombinerMode
from .geometry_utils import segments_distance
from .revolving_areas_utils import (
    get_swapping_areas,
    paths_to_grouped_robots_paths,
    combine_paths_with_revolving_areas,
)


class PathCombiner:
    def __init__(self, robots: List[RobotDisc], min_distance: float):
        assert (
            min_distance >= 0
        ), "Minimum distance between robots must be non negative."

        self.min_distance = min_distance
        self.expanded_robots = []
        for robot in robots:
            robot_dict = robot.to_dict()
            robot_dict["radius"] += self.min_distance / 2
            self.expanded_robots.append(load_object_from_dict(robot_dict))

    @staticmethod
    def robots_on_point(point: Point_d):
        dim = point.dimension()
        assert dim % 2 == 0
        return dim // 2

    def collision_free_point(self, point: List[Point_d]):
        point_list = combined_point_to_combined_point_list(combined_point=point)
        for i, robot1 in enumerate(self.expanded_robots):
            for j, robot2 in enumerate(self.expanded_robots):
                if j <= i:
                    continue

                if collision_detection.collide_disc_with_disc(
                    center1=point_list[i],
                    r1=robot1.radius,
                    center2=point_list[j],
                    r2=robot2.radius,
                ):
                    return False

        return True

    def collision_free_edge(self, point1: List[Point_d], point2: List[Point_d]):
        point1_list = combined_point_to_combined_point_list(point1)
        point2_list = combined_point_to_combined_point_list(point2)
        for i, robot1 in enumerate(self.expanded_robots):
            for j, robot2 in enumerate(self.expanded_robots):
                if j <= i:
                    continue

                edge1 = Segment_2(point1_list[i], point2_list[i])
                edge2 = Segment_2(point1_list[j], point2_list[j])
                # This check is stronger than `collision_detection.collide_two_robots` since it doesn't assume a certain movement on the edges.
                combined_radius = robot1.radius + robot2.radius
                if segments_distance(edge1, edge2) < combined_radius:
                    return False

        return True

    def collision_free_path(self, combined_path: List[List[Point_d]]):
        combined_splitted_path = []
        grouped_robots_indices = []
        total_size = 0
        for path in combined_path:
            group_size = PathCombiner.robots_on_point(path[0])
            grouped_robots_indices.append(range(total_size, total_size + group_size))
            splitted_path: List[List[Point_2]] = [list() for _ in range(group_size)]
            for point in path:
                point_list = conversions.Point_d_to_Point_2_list(point)
                for i, point2 in enumerate(point_list):
                    splitted_path[i].append(point2)
            combined_splitted_path.extend(splitted_path)
            total_size += group_size

        assert total_size == len(self.expanded_robots)  # Sanity check.

        for i, robots_group_indices1 in enumerate(grouped_robots_indices):
            for j, robots_group_indices2 in enumerate(grouped_robots_indices):
                if j <= i:
                    continue

                for robot_idx1 in robots_group_indices1:
                    for robot_idx2 in robots_group_indices2:
                        robot1 = self.expanded_robots[robot_idx1]
                        robot2 = self.expanded_robots[robot_idx2]
                        for edge1 in zip(
                            combined_splitted_path[robot_idx1],
                            combined_splitted_path[robot_idx1][1:],
                        ):
                            edge1 = Segment_2(*edge1)
                            for edge2 in zip(
                                combined_splitted_path[robot_idx2],
                                combined_splitted_path[robot_idx2][1:],
                            ):
                                edge2 = Segment_2(*edge2)
                                # This check is stronger than `collision_detection.collide_two_robots` since it doesn't assume a certain movement on the edges.
                                combined_radius = robot1.radius + robot2.radius
                                if segments_distance(edge1, edge2) < combined_radius:
                                    return False

        return True

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        raise NotImplementedError("Method is not implemented...")


class SequentialPathCombiner(PathCombiner):
    def __init__(self, robots: List[RobotDisc]):
        super().__init__(robots=robots, min_distance=0)

    def two_sequential_combined_path(
        self, first_path: List[Point_d], second_path: List[Point_d]
    ) -> List[Point_d]:
        combined_path = []

        second_path_start = second_path[0]
        second_path_start_list = conversions.Point_d_to_Point_2_list(second_path_start)
        for point in first_path:
            point_list = conversions.Point_d_to_Point_2_list(point)
            combined_path.append(
                conversions.Point_2_list_to_Point_d(point_list + second_path_start_list)
            )

        first_path_end = first_path[-1]
        first_path_end_list = conversions.Point_d_to_Point_2_list(first_path_end)
        for point in second_path[1:]:
            point_list = conversions.Point_d_to_Point_2_list(point)
            combined_path.append(
                conversions.Point_2_list_to_Point_d(first_path_end_list + point_list)
            )

        return combined_path

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        combined_path = paths[0]

        for path in tqdm(paths[1:], desc="Combining paths sequentially"):
            combined_path = self.two_sequential_combined_path(combined_path, path)

        return combined_path


class RevolvingAreasPathCombiner(PathCombiner):
    def __init__(self, robots: List[RobotDisc], obstacles: List[Polygon_2]):
        super().__init__(robots=robots, min_distance=0)
        for robot in self.expanded_robots:
            assert (
                robot.radius.to_double() == 1
            ), "Revolving areas is only supported for robots with radius 1."

        self.obstacles = obstacles

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        starts = []
        targets = []
        for path in paths:
            starts.extend(conversions.Point_d_to_Point_2_list(path[0]))
            targets.extend(conversions.Point_d_to_Point_2_list(path[-1]))
        starts_swapping_areas, targets_swapping_areas = get_swapping_areas(
            obstacles=self.obstacles, starts=starts, targets=targets
        )

        grouped_robot_paths, RA_grouped_robot_paths = paths_to_grouped_robots_paths(
            paths
        )
        assert len(grouped_robot_paths) == len(RA_grouped_robot_paths)

        combined_paths = []
        for robots_paths_group, RA_robots_paths_group in zip(
            grouped_robot_paths, RA_grouped_robot_paths
        ):
            combined_paths.extend(
                combine_paths_with_revolving_areas(
                    robots_paths_group,
                    RA_robots_paths_group,
                    starts_swapping_areas,
                    targets_swapping_areas,
                )
            )

        return combined_paths


class CSpacePathCombiner(PathCombiner):
    def __init__(
        self,
        robots: List[RobotDisc],
        min_distance: float,
        allow_backtracking: bool = True,
    ):
        super().__init__(robots=robots, min_distance=min_distance)
        self.allow_backtracking = allow_backtracking

    def is_valid_edge(
        self, paths_cspace: PathsCSpace, point1: Point_d, point2: Point_d
    ):
        if point1 == point2:
            return True

        if not self.allow_backtracking:
            for i in range(point1.dimension()):
                if point1[i] > point2[i]:
                    return False

        combined_path = paths_cspace.combined_cspace_edge_to_combined_path(
            src=point1, dst=point2
        )

        return self.collision_free_path(combined_path=combined_path)


class PRMPathCombiner(CSpacePathCombiner):
    def __init__(
        self,
        robots: List[RobotDisc],
        num_landmarks: int,
        k: int,
        min_distance: float = 0,
        allow_backtracking: bool = True,
    ):
        super().__init__(
            robots=robots,
            min_distance=min_distance,
            allow_backtracking=allow_backtracking,
        )
        self.num_landmarks = num_landmarks
        self.k = k

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        paths_cspace = PathsCSpace(paths=paths)
        metric = Metric_Linf()

        start_point = paths_cspace.get_combined_start_cspace_point()
        end_point = paths_cspace.get_combined_end_cspace_point()

        roadmap = nx.DiGraph()
        roadmap.add_node(start_point)
        roadmap.add_node(end_point)
        # Add valid points
        for _ in range(self.num_landmarks):
            p_rand = paths_cspace.sample_combined_cspace_point()
            roadmap.add_node(p_rand)

        nearest_neighbors = NearestNeighbors_sklearn(metric=metric)
        nearest_neighbors.fit(list(roadmap.nodes))

        # Connect all points to their k nearest neighbors
        for point in roadmap.nodes:
            neighbors = nearest_neighbors.k_nearest(point, self.k + 1)
            for neighbor in neighbors:
                if self.is_valid_edge(
                    paths_cspace=paths_cspace, point1=point, point2=neighbor
                ):
                    roadmap.add_edge(
                        point,
                        neighbor,
                        weight=metric.dist(point, neighbor).to_double(),
                    )

        if not nx.algorithms.has_path(roadmap, start_point, end_point):
            return None

        combined_cspace_path = nx.algorithms.shortest_path(
            roadmap, start_point, end_point, weight="weight"
        )
        combined_path = paths_cspace.combined_cspace_path_to_combined_path(
            combined_cspace_path=combined_cspace_path
        )

        return combined_path_to_tensor_path(combined_path=combined_path)


class RefinementPathCombiner(CSpacePathCombiner):
    def __init__(
        self,
        robots: List[RobotDisc],
        epsilon: int,
        min_distance: float = 0,
        allow_backtracking: bool = True,
    ):
        super().__init__(
            robots=robots,
            min_distance=min_distance,
            allow_backtracking=allow_backtracking,
        )
        self.epsilon = epsilon

    def get_refined_cspace_path(
        self, start_point: float, end_point: float
    ) -> List[float]:
        refined_cspace_path = [start_point]
        curr_point = start_point
        while curr_point < end_point:
            curr_point += self.epsilon
            curr_point = min(curr_point, end_point)
            refined_cspace_path.append(curr_point)

        return refined_cspace_path

    def get_cspace_neighbors(
        self,
        refined_cspace_paths: List[List[float]],
        point_indices: Tuple[int, ...],
    ) -> List[Point_d]:
        dim = len(refined_cspace_paths)
        cspace_neighbors = []
        paths_amount = len(refined_cspace_paths)
        for neighbor_indices_diff in product([0, 1], repeat=paths_amount):
            # Skipping (0, ..., 0)
            if not any(neighbor_indices_diff):
                continue

            out_of_range = False
            for path_idx, neighbor_idx_diff in enumerate(neighbor_indices_diff):
                if point_indices[path_idx] + neighbor_idx_diff >= len(
                    refined_cspace_paths[path_idx]
                ):
                    out_of_range = True
                    break
            if out_of_range:
                continue

            cspace_neighbors.append(
                Point_d(
                    dim,
                    [
                        refined_cspace_paths[path_idx][
                            point_indices[path_idx] + neighbor_idx_diff
                        ]
                        for path_idx, neighbor_idx_diff in enumerate(
                            neighbor_indices_diff
                        )
                    ],
                )
            )

        return cspace_neighbors

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        paths_cspace = PathsCSpace(paths=paths)
        metric = Metric_Linf()
        dim = len(paths)

        refined_cspace_paths = []
        for path_idx in range(len(paths)):
            start_point = paths_cspace.get_start_cspace_point(path_idx=path_idx)
            end_point = paths_cspace.get_end_cspace_point(path_idx=path_idx)
            refined_cspace_path = self.get_refined_cspace_path(
                start_point=start_point, end_point=end_point
            )
            refined_cspace_paths.append(refined_cspace_path)

        # nodes are added when edges are added.
        roadmap = nx.Graph()
        roadmap.add_node(paths_cspace.get_combined_start_cspace_point())
        roadmap.add_node(paths_cspace.get_combined_end_cspace_point())

        refined_paths_ranges = [
            range(len(refined_path)) for refined_path in refined_cspace_paths
        ]
        total_nodes = 1
        for refined_cspace_path in refined_cspace_paths:
            total_nodes *= len(refined_cspace_path)
        for point_indices in tqdm(
            product(*refined_paths_ranges),
            desc="Creating refinement graph",
            total=total_nodes,
        ):
            combined_cspace_point = Point_d(
                dim,
                [
                    refined_cspace_paths[path_idx][point_idx]
                    for path_idx, point_idx in enumerate(point_indices)
                ],
            )
            if not self.collision_free_point(
                point=paths_cspace.combined_cspace_point_to_combined_point(
                    combined_cspace_point=combined_cspace_point
                )
            ):
                continue
            cspace_neighbors = self.get_cspace_neighbors(
                refined_cspace_paths, point_indices
            )
            for cspace_neighbor in cspace_neighbors:
                if not self.collision_free_point(
                    point=paths_cspace.combined_cspace_point_to_combined_point(
                        combined_cspace_point=cspace_neighbor
                    )
                ):
                    continue

                if self.is_valid_edge(
                    paths_cspace=paths_cspace,
                    point1=combined_cspace_point,
                    point2=cspace_neighbor,
                ):
                    roadmap.add_edge(
                        combined_cspace_point,
                        cspace_neighbor,
                        weight=metric.dist(
                            combined_cspace_point, cspace_neighbor
                        ).to_double(),
                    )

        start = paths_cspace.get_combined_start_cspace_point()
        end = paths_cspace.get_combined_end_cspace_point()
        if not nx.algorithms.has_path(roadmap, start, end):
            return None

        combined_cspace_path = nx.algorithms.shortest_path(
            roadmap, start, end, weight="weight"
        )
        combined_path = paths_cspace.combined_cspace_path_to_combined_path(
            combined_cspace_path=combined_cspace_path
        )

        return combined_path_to_tensor_path(combined_path=combined_path)


class Obstacles2PathCombiner(CSpacePathCombiner):
    def __init__(
        self,
        robots: List[RobotDisc],
        min_distance: float = 0,
        allow_backtracking: bool = True,
    ):
        super().__init__(
            robots=robots,
            min_distance=min_distance,
            allow_backtracking=allow_backtracking,
        )

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        assert len(paths) == 2, "ObstaclePathCombiner suppports only 2 paths."
        MIN_REPORT_PROGRESS = 1 << 15

        paths_cspace = PathsCSpace(paths=paths)
        metric = Metric_Linf()

        robots1_count = PathCombiner.robots_on_point(paths[0][0])
        robots2_count = PathCombiner.robots_on_point(paths[1][0])

        # Sanity check.
        assert robots1_count + robots2_count == len(self.expanded_robots)

        radiuses1 = [
            robot.radius.to_double() for robot in self.expanded_robots[:robots1_count]
        ]
        radiuses2 = [
            robot.radius.to_double() for robot in self.expanded_robots[robots1_count:]
        ]
        cspace_obstacles = paths_cspace.get_cspace_obstacles(
            radiuses1=radiuses1, radiuses2=radiuses2
        )

        start_point = paths_cspace.get_combined_start_cspace_point()
        end_point = paths_cspace.get_combined_end_cspace_point()

        roadmap = nx.Graph()
        roadmap.add_node(start_point)
        roadmap.add_node(end_point)
        # Add points
        for cspace_obstacle in cspace_obstacles:
            for point in cspace_obstacle.vertices():
                point_d = Point_d(2, [point.x().to_double(), point.y().to_double()])
                roadmap.add_node(point_d)

        total_nodes = len(roadmap.nodes) ** 2
        progress = tqdm(
            total=total_nodes,
            desc="Creating obstacles graph",
            disable=total_nodes < MIN_REPORT_PROGRESS,
        )
        # Connect all points
        for i, point1 in enumerate(roadmap.nodes):
            for j, point2 in enumerate(roadmap.nodes):
                progress.update()
                if i == j:
                    continue
                if self.is_valid_edge(
                    paths_cspace=paths_cspace, point1=point1, point2=point2
                ):
                    roadmap.add_edge(
                        point1,
                        point2,
                        weight=metric.dist(point1, point2).to_double(),
                    )
        progress.close()

        if not nx.algorithms.has_path(roadmap, start_point, end_point):
            return None

        combined_cspace_path = nx.algorithms.shortest_path(
            roadmap, start_point, end_point, weight="weight"
        )
        combined_path = paths_cspace.combined_cspace_path_to_combined_path(
            combined_cspace_path=combined_cspace_path
        )

        return combined_path_to_tensor_path(combined_path=combined_path)


class PairsPathCombiner(PathCombiner):
    def __init__(
        self,
        robots: List[RobotDisc],
        path_combiner_factory: "PathCombinerFactory",
        path_combiner_mode: PathCombinerMode,
        depth: int = 1,
        pairing_k: int = -1,
        max_simultaneous_robots: int = -1,
        min_distance: float = 0,
    ):
        super().__init__(robots=robots, min_distance=min_distance)
        self.robots = robots
        self.path_combiner_factory = path_combiner_factory
        self.path_combiner_mode = path_combiner_mode
        self.depth = depth
        self.max_simultaneous_robots = max_simultaneous_robots
        self.pairing_k = pairing_k

    def combine_paths(self, paths: List[List[Point_d]]) -> Optional[List[Point_d]]:
        grouped_robots = []
        group_size_cumsum = [0]
        total_size = 0
        for path in paths:
            group_size = PathCombiner.robots_on_point(path[0])
            grouped_robots.append(self.robots[total_size : total_size + group_size])
            group_size_cumsum.append(group_size_cumsum[-1] + group_size)
            total_size += group_size

        assert total_size == len(self.robots)  # Sanity check.

        graph = nx.Graph()

        # Add nodes for the double graph.
        for i in range(len(grouped_robots)):
            graph.add_node((i, 0))
            graph.add_node((i, 1))

        paths_num = len(paths)
        robots_indices = range(paths_num)
        sample_amount = self.pairing_k if self.pairing_k != -1 else paths_num
        sample_amount = min(sample_amount, paths_num)
        progress = tqdm(
            desc=f"Combining pairs ({self.depth = })",
            total=len(robots_indices) * (sample_amount + 1),
        )
        for i in robots_indices:
            progress.update()

            # Edge for no pairing.
            graph.add_edge(
                (i, 0),
                (i, 1),
                weight=2 * path_makespan_d(paths[i]),
                path=paths[i],
                robots_indices=[i],
            )

            for j in random.sample(robots_indices, k=sample_amount):
                progress.update()

                robots1 = grouped_robots[i]
                robots2 = grouped_robots[j]
                path1 = paths[i]
                path2 = paths[j]

                # Sanity check.
                assert len(conversions.Point_d_to_Point_2_list(path1[0])) == len(
                    robots1
                )
                assert len(conversions.Point_d_to_Point_2_list(path2[0])) == len(
                    robots2
                )

                # Already addded this edge.
                if i == j:
                    continue

                total_simultaneous_robots = len(robots1) + len(robots2)
                if (
                    self.max_simultaneous_robots != -1
                    and total_simultaneous_robots > self.max_simultaneous_robots
                ):
                    # print(
                    #     f"Skipping combination of robots since {total_simultaneous_robots = } and {self.max_simultaneous_robots = }."
                    # )
                    continue

                # No need to try combining paths if start / end positions do not have minimal distance requirement.
                valid_start_end_positions = True
                for robot1, robot2 in product(robots1, robots2):
                    allowed_dist = robot1.radius + robot2.radius + self.min_distance
                    start_dist = l2_dist(robot1.start, robot2.start)
                    end_dist = l2_dist(robot1.end, robot2.end)
                    if start_dist < allowed_dist or end_dist < allowed_dist:
                        valid_start_end_positions = False
                        break
                if not valid_start_end_positions:
                    # print(
                    #     f"Skipping combination of robots since start / end position do not have minimal distance requirement."
                    # )
                    continue

                path_combiner = self.path_combiner_factory.create_path_combiner(
                    mode=self.path_combiner_mode,
                    robots=robots1 + robots2,
                    min_distance=self.min_distance,
                )

                combined_path = path_combiner.combine_paths([path1, path2])
                if not combined_path:
                    continue

                makespan = path_makespan_d(combined_path)
                graph.add_edge(
                    (i, 0),
                    (j, 0),
                    weight=makespan,
                    path=combined_path,
                    robots_indices=[i, j],
                )
                graph.add_edge(
                    (i, 1),
                    (j, 1),
                    weight=makespan,
                    path=combined_path,
                    robots_indices=[i, j],
                )
        progress.close()

        print("Finding minimum matching...")
        matching = nx.min_weight_matching(graph, weight="weight")
        print("Found minimum matching")

        grouped_robots_permutation = []
        paired_paths = []
        for u, v in matching:
            # Ignore copy graph.
            if u[1] == v[1] == 1:
                continue

            edge_data = graph.get_edge_data(u, v)
            grouped_robots_permutation.extend(edge_data["robots_indices"])

            paired_paths.append(edge_data["path"])
        graph = None  # No need for the graph anymore.

        # Sanity check.
        assert set(grouped_robots_permutation) == set(range(len(grouped_robots)))

        robots_permutation = []
        for idx in grouped_robots_permutation:
            robots_permutation.extend(
                list(range(group_size_cumsum[idx], group_size_cumsum[idx + 1]))
            )
        # Sanity check.
        assert set(robots_permutation) == set(range(len(self.robots)))

        reordered_robots = []
        for i in robots_permutation:
            reordered_robots.append(self.robots[i])

        if self.depth > 1:
            path_combiner = self.path_combiner_factory.create_path_combiner(
                mode=PathCombinerMode.PAIRS,
                robots=reordered_robots,
                sub_mode=self.path_combiner_mode,
                depth=self.depth - 1,
                pairing_k=self.pairing_k,
                max_simultaneous_robots=self.max_simultaneous_robots,
                min_distance=self.min_distance,
            )
        else:
            # robots are ignored in this combiner so the permutation of robots does not matter.
            path_combiner = self.path_combiner_factory.create_path_combiner(
                mode=PathCombinerMode.REVOLVING_AREAS, robots=reordered_robots
            )

        combined_path = path_combiner.combine_paths(paths=paired_paths)

        reordered_combined_path = []
        reordered_points = [None] * len(self.robots)
        for point_d in tqdm(combined_path, desc="Finalizing path"):
            points = conversions.Point_d_to_Point_2_list(point_d)
            for i, point in enumerate(points):
                reordered_points[robots_permutation[i]] = point

            reordered_combined_path.append(
                conversions.Point_2_list_to_Point_d(reordered_points)
            )

        return reordered_combined_path
