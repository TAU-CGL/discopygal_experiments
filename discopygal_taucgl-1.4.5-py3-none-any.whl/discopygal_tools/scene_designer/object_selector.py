from discopygal.solvers_infra import *
from discopygal.geometry_utils import conversions, collision_detection, transform

SELECTION_EPS = 0.1

class ObjectSelector(object):
    """
    A class that handles selection of scene objects
    """
    def __init__(self, gui):
        self.gui = gui
        self.selected = None
    
    def left_click_handle(self, x, y):
        """
        Handle selection of objects
        """
        self.gui.scene_drawer.deselect_entity(self.selected)
        self.selected = None

        relevant = self.find_all_relevant(x, y)
        if len(relevant) > 0:
            self.selected = relevant[-1]
            self.gui.update_object_properties(select=True)
            self.gui.scene_drawer.select_entity(self.selected)
        else:
            self.gui.update_object_properties(select=False)
        

    
    def find_all_relevant(self, x, y):
        """
        Find all scene objects that are close to the given (x,y) coordinate
        """
        res = []

        # Convert selection to CGAL objects
        center = conversions.xy_to_Point_2(x, y)
        r = conversions.float_to_FT(SELECTION_EPS)

        for obstacle in self.gui.discopygal_scene.obstacles:
            if type(obstacle) == ObstaclePolygon and collision_detection.collide_disc_with_polygon(center, r, obstacle.poly):
                res.append(obstacle)
            if type(obstacle) == ObstacleDisc and collision_detection.collide_disc_with_disc(center, r, obstacle.location, obstacle.radius):
                res.append(obstacle)
        
        for robot in self.gui.discopygal_scene.robots:
            if type(robot) == RobotPolygon:
                if collision_detection.collide_disc_with_polygon(center, r, transform.offset_polygon(robot.poly, robot.start)):
                    res.append(robot)
                elif collision_detection.collide_disc_with_polygon(center, r, transform.offset_polygon(robot.poly, robot.end)):
                    res.append(robot)
            if type(robot) == RobotDisc:
                if collision_detection.collide_disc_with_disc(center, r, robot.start, robot.radius):
                    res.append(robot)
                elif collision_detection.collide_disc_with_disc(center, r, robot.end, robot.radius):
                    res.append(robot)
            if type(robot) == RobotRod:
                if collision_detection.collide_disc_with_rod(center, r, robot.start[0].x(), robot.start[0].y(), robot.start[1], robot.length):
                    res.append(robot)
                elif collision_detection.collide_disc_with_rod(center, r, robot.end[0].x(), robot.end[0].y(), robot.end[1], robot.length):
                    res.append(robot)

        return res