from PyQt5 import QtCore, QtWidgets

from discopygal.solvers_infra import *
from discopygal.geometry_utils import conversions


OBJDRW_OBJ_TYPE_OBST_POLY = 0
OBJDRW_OBJ_TYPE_OBST_DISC = 1
OBJDRW_OBJ_TYPE_ROBOT_POLY = 2
OBJDRW_OBJ_TYPE_ROBOT_DISC = 3
OBJDRW_OBJ_TYPE_ROBOT_ROD = 4

OBJDRW_OBJ_TYPE_NAMES = {
    OBJDRW_OBJ_TYPE_OBST_POLY: "Drawing polygonal obstacle",
    OBJDRW_OBJ_TYPE_OBST_DISC: "Drawing disc obstacle",
    OBJDRW_OBJ_TYPE_ROBOT_POLY: "Drawing polygonal robot",
    OBJDRW_OBJ_TYPE_ROBOT_DISC: "Drawing disc robot",
    OBJDRW_OBJ_TYPE_ROBOT_ROD: "Drawing rod robot",
}

OBJDRW_MODE_NONE = 0
OBJDRW_MODE_POLYLINE = 1
OBJDRW_MODE_START = 2
OBJDRW_MODE_END = 3

OBJDRW_MODE_NAMES = {
    OBJDRW_MODE_NONE: "",
    OBJDRW_MODE_POLYLINE: "Polygonal line",
    OBJDRW_MODE_START: "Selecting start position",
    OBJDRW_MODE_END: "Selecting end position",
}

OBJDRW_STATUS_MSG = "{}: {}"

OBJDRW_POINT_RADIUS = 0.1
OBJDRW_POLYLINE_COLOR = QtCore.Qt.red

OBJDRW_DEFAULT_RADIUS = 1.0
OBJDRW_DEFAULT_LENGTH = 1.0
OBJDRW_DEFAULT_START_ANGLE = 0.0
OBJDRW_DEFAULT_END_ANGLE = 0.0


class ObjectDrawer(object):
    """
    A class that handles creation of objects in the scene
    When an object is finished drawing - then add it to the scene
    """
    def __init__(self, gui):
        self.gui = gui
    
        self.polyline = []
        self.polyline_segments = []
        self.polyline_vertices = []
        self.start_pos = None
        self.start_pos_gui = None
        self.end_pos = None
        self.end_pos_gui = None

    def update_status_msg(self):
        msg = OBJDRW_STATUS_MSG.format(OBJDRW_OBJ_TYPE_NAMES[self.obj_type], OBJDRW_MODE_NAMES[self.mode])
        self.gui.statusbar.showMessage(msg)
    
    def clear_drawing(self):
        """
        Discard any drawings currently made
        """
        for segment in self.polyline_segments:
            self.gui.scene.removeItem(segment.line)
        for vertex in self.polyline_vertices:
            self.gui.scene.removeItem(vertex.disc)
        self.polyline.clear()
        self.polyline_segments.clear()
        self.polyline_vertices.clear()

        self.start_pos = None
        if self.start_pos_gui is not None:
            self.gui.scene.removeItem(self.start_pos_gui.disc)
            self.start_pos_gui = None
        self.end_pos = None
        if self.end_pos_gui is not None:
            self.gui.scene.removeItem(self.end_pos_gui.disc)
            self.end_pos_gui = None

    
    def set_object_type_drawing(self, obj_type):
        """
        Set the new object type mode (and the according draw mode)
        Also discard any previous drawing made by user
        """
        self.clear_drawing()

        self.obj_type = obj_type
        if obj_type in [OBJDRW_OBJ_TYPE_OBST_POLY, OBJDRW_OBJ_TYPE_ROBOT_POLY]:
            self.mode = OBJDRW_MODE_POLYLINE
        else:
            self.mode = OBJDRW_MODE_START
        self.update_status_msg()

        self.gui.update_object_properties(select=False)


    def right_click_handle(self, x: float, y: float):
        """
        Handle right clicks (when drawing a scene)
        """
        # Show the status bar message again
        self.update_status_msg()
        self.gui.update_object_properties(select=False)
        self.gui.object_selector.selected = None

        # Round selection to nearest grid point
        resolution = self.gui.grid.resolution
        x = resolution * round(x / resolution)
        y = resolution * round(y / resolution) 
        
        # Handle drawing of polygonal lines
        if self.mode == OBJDRW_MODE_POLYLINE:
            if [x,y] in self.polyline:
                # Handle closing the polygon
                if self.obj_type == OBJDRW_OBJ_TYPE_OBST_POLY:
                    self.add_poly_obstacle()
                elif self.obj_type == OBJDRW_OBJ_TYPE_ROBOT_POLY:
                    # If we draw a polygonal robot, we now need to select start and end locations
                    self.mode = OBJDRW_MODE_START
                    self.update_status_msg()
                    # Also close the polyline
                    self.polyline.append([x,y])
                    self.polyline_vertices.append(self.gui.add_disc(OBJDRW_POINT_RADIUS, x, y, fill_color=OBJDRW_POLYLINE_COLOR))
                    if len(self.polyline) > 1:
                        self.polyline_segments.append(self.gui.add_segment(*self.polyline[-2], *self.polyline[-1], line_color=OBJDRW_POLYLINE_COLOR))
            else:
                self.polyline.append([x,y])
                self.polyline_vertices.append(self.gui.add_disc(OBJDRW_POINT_RADIUS, x, y, fill_color=OBJDRW_POLYLINE_COLOR))
                if len(self.polyline) > 1:
                    self.polyline_segments.append(self.gui.add_segment(*self.polyline[-2], *self.polyline[-1], line_color=OBJDRW_POLYLINE_COLOR))
            return

        # Handle selection of start location
        if self.mode == OBJDRW_MODE_START:
            self.start_pos = [x,y]
            self.start_pos_gui = self.gui.add_disc(OBJDRW_POINT_RADIUS * 2, x, y, fill_color=QtCore.Qt.blue)
            
            if self.obj_type == OBJDRW_OBJ_TYPE_OBST_DISC:
                self.add_disc_obstacle()
            if self.obj_type in [OBJDRW_OBJ_TYPE_ROBOT_POLY, OBJDRW_OBJ_TYPE_ROBOT_DISC, OBJDRW_OBJ_TYPE_ROBOT_ROD]:
                self.mode = OBJDRW_MODE_END
                self.update_status_msg()
            return
        
        # Handle selection of end location
        if self.mode == OBJDRW_MODE_END:
            self.end_pos = [x,y]
            self.end_pos_gui = self.gui.add_disc(OBJDRW_POINT_RADIUS * 2, x, y, fill_color=QtCore.Qt.green)
            
            if self.obj_type == OBJDRW_OBJ_TYPE_ROBOT_POLY:
                self.add_poly_robot()
                self.mode = OBJDRW_MODE_POLYLINE
                self.update_status_msg()
            if self.obj_type == OBJDRW_OBJ_TYPE_ROBOT_DISC:
                self.add_disc_robot()
                self.mode = OBJDRW_MODE_START
                self.update_status_msg()
            if self.obj_type == OBJDRW_OBJ_TYPE_ROBOT_ROD:
                self.add_rod_robot()
                self.mode = OBJDRW_MODE_START
                self.update_status_msg()
            return
    
    def refresh_scene(self):
        self.clear_drawing()
        self.gui.scene_drawer.clear_scene()
        self.gui.scene_drawer.draw_scene()

    def add_poly_obstacle(self):
        """
        Add polygonal obstacle to scene after finished drawing
        """
        self.gui.scene_changed()
        # Generate a polygonal obstacle in the scene
        poly = conversions.array_of_points_to_Polygon_2(self.polyline)
        data = self.gui.get_object_properties()

        poly_obst = ObstaclePolygon(poly, data)
        self.gui.discopygal_scene.add_obstacle(poly_obst)
        self.refresh_scene()

    def add_disc_obstacle(self):
        """
        Add disc obstacle to scene after finished drawing
        """
        self.gui.scene_changed()
        location = conversions.xy_to_Point_2(*self.start_pos)
        radius = conversions.float_to_FT(float(self.gui.get_property("radius")))
        data = self.gui.get_object_properties()

        disc_obst = ObstacleDisc(location, radius, data)
        self.gui.discopygal_scene.add_obstacle(disc_obst)
        self.refresh_scene()

    def add_poly_robot(self):
        """
        Add polygonal robot to the scene after finished drawing
        """
        self.gui.scene_changed()
        poly = conversions.array_of_points_to_Polygon_2(self.polyline)
        start = conversions.xy_to_Point_2(*self.start_pos)
        end = conversions.xy_to_Point_2(*self.end_pos)
        data = self.gui.get_object_properties()

        poly_robot = RobotPolygon(poly, start, end, data)
        self.gui.discopygal_scene.add_robot(poly_robot)
        self.refresh_scene()

    def add_disc_robot(self):
        """
        Add disc robot to the scene after finished drawing
        """
        self.gui.scene_changed()
        radius = conversions.float_to_FT(float(self.gui.get_property("radius")))
        start = conversions.xy_to_Point_2(*self.start_pos)
        end = conversions.xy_to_Point_2(*self.end_pos)
        data = self.gui.get_object_properties()

        disc_robot = RobotDisc(radius, start, end, data)
        self.gui.discopygal_scene.add_robot(disc_robot)
        self.refresh_scene()
    
    def add_rod_robot(self):
        """
        Add rod robot to the scene after finished drawing
        """
        self.gui.scene_changed()
        length = conversions.float_to_FT(float(self.gui.get_property("length")))
        start_angle = conversions.float_to_FT(float(self.gui.get_property("start_angle")))
        end_angle = conversions.float_to_FT(float(self.gui.get_property("end_angle")))
        start = conversions.xy_to_Point_2(*self.start_pos), start_angle
        end = conversions.xy_to_Point_2(*self.end_pos), end_angle
        data = self.gui.get_object_properties()

        rod_robot = RobotRod(length, start, end, data)
        self.gui.discopygal_scene.add_robot(rod_robot)
        self.refresh_scene()